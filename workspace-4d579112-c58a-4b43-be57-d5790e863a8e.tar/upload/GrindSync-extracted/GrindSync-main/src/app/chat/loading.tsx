import { SectionLoading } from "@/components/social-grind/SectionLoading";

export default function ChatLoading() {
  return (
    <SectionLoading
      title="Loading chat"
      subtitle="Opening your conversations"
      rows={4}
    />
  );
}
