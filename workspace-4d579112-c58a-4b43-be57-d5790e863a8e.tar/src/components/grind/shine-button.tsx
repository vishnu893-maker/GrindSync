"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

interface ShineButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  className?: string;
}

/**
 * Primary CTA with a diagonal shine sweep + glow on hover.
 * Inspired by uiverse.io shine / glow buttons.
 */
export const ShineButton = React.forwardRef<HTMLButtonElement, ShineButtonProps>(
  function ShineButton({ children, className, ...props }, ref) {
    return (
      <button
        ref={ref}
        {...props}
        className={cn(
          "group relative inline-flex h-11 items-center justify-center gap-2 overflow-hidden rounded-xl px-6 text-base font-semibold",
          "bg-brand text-brand-foreground shadow-[0_8px_30px_-8px_color-mix(in_oklch,var(--color-brand)_60%,transparent)]",
          "transition-transform duration-200 hover:scale-[1.02] active:scale-[0.98]",
          className,
        )}
      >
        {/* shine sweep */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 -translate-x-full bg-[linear-gradient(110deg,transparent_30%,color-mix(in_oklch,var(--color-brand-foreground)_35%,transparent)_50%,transparent_70%)] transition-transform duration-700 ease-out group-hover:translate-x-full"
        />
        {/* top sheen */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/15 to-transparent"
        />
        {/* content */}
        <span className="relative z-10 inline-flex items-center gap-2">
          {children}
        </span>
      </button>
    );
  },
);
