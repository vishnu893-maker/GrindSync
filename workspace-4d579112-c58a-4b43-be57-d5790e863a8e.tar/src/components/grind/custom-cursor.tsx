"use client";

import * as React from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/**
 * Sleek custom cursor — a small rounded-square (squircle) that spring-follows
 * the pointer, grows + rotates into a diamond over interactive elements, and
 * uses mix-blend-difference so it stays visible on any background.
 *
 * Non-circular by design. Disabled on touch / coarse-pointer devices and when
 * prefers-reduced-motion is set (native cursor remains).
 */
export function CustomCursor() {
  const x = useMotionValue(-100);
  const y = useMotionValue(-100);
  const springConfig = { stiffness: 520, damping: 32, mass: 0.35 };
  const sx = useSpring(x, springConfig);
  const sy = useSpring(y, springConfig);

  const [enabled, setEnabled] = React.useState(false);
  const [hovering, setHovering] = React.useState(false);
  const [down, setDown] = React.useState(false);
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    const fine = window.matchMedia("(pointer: fine)").matches;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (!fine || reduced) return;
    setEnabled(true);
    // hide native cursor on this device
    document.documentElement.classList.add("gs-custom-cursor");

    const interactiveSel =
      "a, button, [role='button'], input, textarea, select, summary, label, [data-cursor-hover]";

    const move = (e: PointerEvent) => {
      x.set(e.clientX);
      y.set(e.clientY);
      setVisible(true);
      const t = e.target as HTMLElement | null;
      setHovering(!!t?.closest(interactiveSel));
    };
    const leave = () => setVisible(false);
    const downFn = () => setDown(true);
    const upFn = () => setDown(false);

    window.addEventListener("pointermove", move, { passive: true });
    document.addEventListener("pointerleave", leave);
    window.addEventListener("pointerdown", downFn, { passive: true });
    window.addEventListener("pointerup", upFn, { passive: true });
    return () => {
      window.removeEventListener("pointermove", move);
      document.removeEventListener("pointerleave", leave);
      window.removeEventListener("pointerdown", downFn);
      window.removeEventListener("pointerup", upFn);
      document.documentElement.classList.remove("gs-custom-cursor");
    };
  }, [x, y]);

  if (!enabled) return null;

  return (
    <motion.div
      aria-hidden
      className="pointer-events-none fixed left-0 top-0 z-[9999] mix-blend-difference"
      style={{ x: sx, y: sy, opacity: visible ? 1 : 0 }}
    >
      <motion.div
        animate={{
          width: hovering ? 34 : 12,
          height: hovering ? 34 : 12,
          rotate: hovering ? 45 : 0,
          scale: down ? 0.75 : 1,
        }}
        transition={{ type: "spring", stiffness: 320, damping: 18 }}
        className="-translate-x-1/2 -translate-y-1/2 rounded-[4px] bg-white"
        style={{ marginLeft: -6, marginTop: -6 }}
      />
    </motion.div>
  );
}
