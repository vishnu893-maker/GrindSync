"use client";

import * as React from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Zap } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const NAV_LINKS = [
  { name: "Dashboard", href: "#dashboard" },
  { name: "Leaderboard", href: "#leaderboard" },
  { name: "Features", href: "#features" },
];

export function TopNav({
  onSignIn,
  onGetStarted,
}: {
  onSignIn?: () => void;
  onGetStarted?: () => void;
}) {
  const [scrolled, setScrolled] = React.useState(false);
  const [open, setOpen] = React.useState(false);

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock body scroll when mobile menu open
  React.useEffect(() => {
    if (open) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        document.body.style.overflow = prev;
      };
    }
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "border-b border-border/70 bg-background/80 backdrop-blur-xl supports-[backdrop-filter]:bg-background/60"
          : "border-b border-transparent bg-transparent",
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
        <Link
          href="#top"
          className="group flex items-center gap-2.5"
          aria-label="GrindSync home"
        >
          <span className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-foreground text-background">
            <Zap className="h-4 w-4" strokeWidth={2.5} />
          </span>
          <span className="text-[15px] font-semibold tracking-tight">
            Grind<span className="text-brand">Sync</span>
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 md:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
            >
              {link.name}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          <ThemeToggle />
          <button
            type="button"
            onClick={onSignIn}
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Sign in
          </button>
          <Button
            onClick={onGetStarted}
            size="sm"
            className="h-9 rounded-lg bg-brand text-brand-foreground hover:bg-brand/90"
          >
            Start grinding
          </Button>
        </div>

        {/* Mobile controls */}
        <div className="flex items-center gap-2 md:hidden">
          <ThemeToggle />
          <button
            type="button"
            aria-label="Open menu"
            onClick={() => setOpen((v) => !v)}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background/60 text-foreground/80"
          >
            {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile sheet menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
            className="md:hidden"
          >
            <div className="border-t border-border bg-background/95 backdrop-blur-xl">
              <nav className="mx-auto flex max-w-7xl flex-col gap-1 px-4 py-3">
                {NAV_LINKS.map((link) => (
                  <a
                    key={link.name}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="rounded-md px-3 py-2.5 text-base font-medium text-foreground/80 transition-colors hover:bg-muted hover:text-foreground"
                  >
                    {link.name}
                  </a>
                ))}
                <div className="mt-2 flex flex-col gap-2 border-t border-border pt-3">
                  <button
                    type="button"
                    onClick={() => {
                      setOpen(false);
                      onSignIn?.();
                    }}
                    className="rounded-md px-3 py-2.5 text-left text-base font-medium text-muted-foreground hover:text-foreground"
                  >
                    Sign in
                  </button>
                  <Button
                    onClick={() => {
                      setOpen(false);
                      onGetStarted?.();
                    }}
                    className="h-10 rounded-lg bg-brand text-brand-foreground hover:bg-brand/90"
                  >
                    Start grinding
                  </Button>
                </div>
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
