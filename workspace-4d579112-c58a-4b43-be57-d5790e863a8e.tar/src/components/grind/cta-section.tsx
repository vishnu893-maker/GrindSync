"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { STATS } from "./data";

export function CTASection({
  onSignIn,
  onGetStarted,
}: {
  onSignIn?: () => void;
  onGetStarted?: () => void;
}) {
  return (
    <section
      id="changelog"
      className="scroll-mt-20 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Stats band */}
        <div className="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border lg:grid-cols-4">
          {STATS.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.07 }}
              className="flex flex-col gap-1 bg-card px-5 py-6 text-center"
            >
              <div className="tnum text-3xl font-semibold tracking-tight sm:text-4xl">
                {s.value}
              </div>
              <div className="text-sm font-medium">{s.label}</div>
              <div className="text-xs text-muted-foreground">{s.sub}</div>
            </motion.div>
          ))}
        </div>

        {/* Final CTA */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
          className="relative mt-6 overflow-hidden rounded-2xl border border-border bg-foreground px-6 py-12 text-center text-background sm:px-12 sm:py-16"
        >
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 opacity-[0.07]"
            style={{
              backgroundImage:
                "radial-gradient(circle at 1px 1px, currentColor 1px, transparent 0)",
              backgroundSize: "18px 18px",
            }}
          />
          <div
            aria-hidden
            className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full opacity-40 blur-3xl"
            style={{
              background:
                "radial-gradient(closest-side, var(--color-brand), transparent)",
            }}
          />
          <div className="relative mx-auto max-w-2xl">
            <h2 className="text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
              Stop describing your grind.
              <br className="hidden sm:block" />
              <span className="text-brand">Show it.</span>
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-balance text-sm text-background/70 sm:text-base">
              Join thousands of developers turning real commits and solved
              problems into rank, reputation and opportunity.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Button
                onClick={onGetStarted}
                size="lg"
                className="h-11 rounded-xl bg-brand px-6 text-base text-brand-foreground hover:bg-brand/90"
              >
                <span className="flex items-center gap-2">
                  Claim your profile
                  <ArrowRight className="h-4 w-4" />
                </span>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-11 rounded-xl border-background/30 bg-transparent px-6 text-base text-background hover:bg-background/10 hover:text-background"
              >
                <a href="#leaderboard">Explore the board</a>
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
