"use client";

import { motion } from "framer-motion";
import { ArrowUpRight, Calendar, Sparkles } from "lucide-react";
import { StatCards } from "../widgets/stat-cards";
import { ContributionGraph } from "../widgets/contribution-graph";
import { CommitChart } from "../widgets/commit-chart";
import { XpBreakdown } from "../widgets/xp-breakdown";
import { DailyDsa } from "../widgets/daily-dsa";
import { ActivityFeed } from "../widgets/activity-feed";
import { MiniLeaderboard } from "../widgets/mini-leaderboard";
import { ActiveChallenges } from "../widgets/active-challenges";
import { OnlineBuilders } from "../widgets/online-builders";
import { WeeklyGoal } from "../widgets/weekly-goal";
import { ME } from "../data";

type ViewId =
  | "dashboard"
  | "leaderboard"
  | "challenges"
  | "network"
  | "chat"
  | "profile";

export function DashboardView({
  onNavigate,
}: {
  onNavigate: (v: ViewId) => void;
}) {
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "short",
    day: "numeric",
  });

  return (
    <div className="flex flex-col gap-5">
      {/* Greeting */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      >
        <div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <Calendar className="h-3.5 w-3.5" />
            {today}
          </div>
          <h2 className="mt-1 text-2xl font-semibold tracking-tight sm:text-3xl">
            {greet}, {ME.name.split(" ")[0]}.
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            You're on a{" "}
            <span className="font-semibold text-brand">{ME.streak}-day streak</span>
            . Keep it alive today.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate("leaderboard")}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-border bg-background px-3 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowUpRight className="h-3.5 w-3.5" />
            <span className="tnum">#{ME.rank}</span>
            <span>global</span>
          </button>
          <button
            onClick={() => onNavigate("challenges")}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-brand px-3 text-xs font-semibold text-brand-foreground transition-colors hover:bg-brand/90"
          >
            <Sparkles className="h-3.5 w-3.5" />
            Today's challenges
          </button>
        </div>
      </motion.div>

      {/* Stat cards */}
      <StatCards />

      {/* Contribution graph + weekly goal */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ContributionGraph />
        </div>
        <div>
          <WeeklyGoal />
        </div>
      </div>

      {/* Mid grid */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <CommitChart />
        <XpBreakdown />
        <DailyDsa />
      </div>

      {/* Activity + leaderboard */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ActivityFeed />
        </div>
        <div>
          <MiniLeaderboard />
        </div>
      </div>

      {/* Challenges + builders */}
      <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ActiveChallenges />
        </div>
        <div>
          <OnlineBuilders />
        </div>
      </div>
    </div>
  );
}
