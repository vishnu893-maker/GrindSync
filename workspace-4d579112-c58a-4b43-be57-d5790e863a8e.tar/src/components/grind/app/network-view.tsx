"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Search, UserCheck, UserPlus, Flame } from "lucide-react";
import { DISCOVER_BUILDERS } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export function NetworkView() {
  const [query, setQuery] = React.useState("");
  const [following, setFollowing] = React.useState<Record<string, boolean>>({
    "@ishita": true,
    "@kabir": true,
  });

  const list = DISCOVER_BUILDERS.filter((b) =>
    query.trim()
      ? b.name.toLowerCase().includes(query.toLowerCase()) ||
        b.tech.some((t) => t.toLowerCase().includes(query.toLowerCase()))
      : true,
  );

  return (
    <div className="flex flex-col gap-5">
      {/* Search + stats */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-sm">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name or stack (Rust, Go…)…"
            className="h-9 w-full rounded-lg border border-border bg-muted/40 pl-8 pr-3 text-sm placeholder:text-muted-foreground focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
          />
        </div>
        <div className="flex items-center gap-4 text-xs text-muted-foreground">
          <span>
            <span className="tnum font-semibold text-foreground">1,204</span> online
          </span>
          <span>
            <span className="tnum font-semibold text-foreground">12.4k</span> builders
          </span>
        </div>
      </div>

      {/* Builder cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((b, i) => {
          const isFollowing = following[b.handle];
          return (
            <motion.article
              key={b.handle}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
              className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4"
            >
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Avatar className="h-11 w-11 border border-border">
                    <AvatarImage src={b.avatar} alt={b.name} />
                    <AvatarFallback>{b.name.slice(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card bg-brand" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-semibold">{b.name}</div>
                  <div className="truncate text-[11px] text-muted-foreground">
                    {b.handle} · {b.followers} followers
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <Flame className="h-3 w-3 text-[oklch(0.65_0.2_25)]" />
                <span className="tnum font-medium text-foreground">{b.streak}d</span> streak
                <span className="mx-1">·</span>
                Lvl <span className="tnum font-medium text-foreground">{b.level}</span> {b.levelName}
              </div>

              <div className="flex flex-wrap gap-1">
                {b.tech.map((t) => (
                  <span key={t} className="rounded border border-border bg-muted/40 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                    {t}
                  </span>
                ))}
              </div>

              {b.mutual > 0 && (
                <div className="text-[10px] text-muted-foreground">
                  <span className="tnum">{b.mutual}</span> mutual connection{b.mutual > 1 ? "s" : ""}
                </div>
              )}

              <Button
                onClick={() => setFollowing((p) => ({ ...p, [b.handle]: !p[b.handle] }))}
                variant={isFollowing ? "outline" : "default"}
                size="sm"
                className={cn(
                  "mt-auto h-8 w-full text-xs",
                  !isFollowing && "bg-brand text-brand-foreground hover:bg-brand/90",
                )}
              >
                {isFollowing ? (
                  <>
                    <UserCheck className="h-3.5 w-3.5" /> Following
                  </>
                ) : (
                  <>
                    <UserPlus className="h-3.5 w-3.5" /> Follow
                  </>
                )}
              </Button>
            </motion.article>
          );
        })}
      </div>

      {list.length === 0 && (
        <div className="rounded-xl border border-dashed border-border py-16 text-center text-sm text-muted-foreground">
          No builders found. Try a different name or stack.
        </div>
      )}
    </div>
  );
}
