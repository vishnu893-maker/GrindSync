"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowDown, ArrowUp, Minus, Flame, Crown } from "lucide-react";
import { LEADERBOARD, ME } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BuilderHoverCard } from "../widgets/builder-hover-card";
import { cn } from "@/lib/utils";

const PERIODS = [
  { id: "week", label: "Weekly" },
  { id: "month", label: "Monthly" },
  { id: "all", label: "All-time" },
] as const;

export function LeaderboardView() {
  const [period, setPeriod] = React.useState<
    (typeof PERIODS)[number]["id"]
  >("week");

  return (
    <div className="flex flex-col gap-5">
      {/* Filter bar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="inline-flex items-center gap-1 rounded-lg border border-border bg-muted/40 p-1">
          {PERIODS.map((p) => (
            <button
              key={p.id}
              onClick={() => setPeriod(p.id)}
              className={cn(
                "relative rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                period === p.id ? "text-background" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {period === p.id && (
                <motion.span
                  layoutId="app-lb-period"
                  className="absolute inset-0 rounded-md bg-brand"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{p.label}</span>
            </button>
          ))}
        </div>
        <div className="text-xs text-muted-foreground">
          <span className="tnum font-semibold text-foreground">184,920</span> builders ranked
        </div>
      </div>

      {/* Podium */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        {LEADERBOARD.slice(0, 3).map((u, i) => (
          <PodiumCard key={u.handle} user={u} index={i} />
        ))}
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="hidden grid-cols-[48px_1fr_80px_80px_80px_60px] gap-3 border-b border-border bg-muted/30 px-4 py-2 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground sm:grid sm:px-5">
          <div>Rank</div>
          <div>Builder</div>
          <div className="text-right">Commits</div>
          <div className="text-right">Solved</div>
          <div className="text-right">Streak</div>
          <div className="text-right">XP</div>
        </div>
        <ul>
          {LEADERBOARD.map((u) => (
            <Row key={u.handle} user={u} />
          ))}
          <YourRow />
        </ul>
      </div>
    </div>
  );
}

function PodiumCard({
  user,
  index,
}: {
  user: (typeof LEADERBOARD)[number];
  index: number;
}) {
  const medal = ["🥇", "🥈", "🥉"][index];
  const highlight = index === 0;
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: index * 0.06 }}
      className={cn(
        "relative flex flex-col items-center gap-2 rounded-xl border bg-card p-5 text-center",
        highlight ? "border-brand/40 shadow-lg shadow-brand/5" : "border-border",
      )}
    >
      {highlight && (
        <span className="absolute -top-2.5 rounded-full bg-brand px-2 py-0.5 text-[9px] font-bold uppercase tracking-wide text-brand-foreground">
          #1 Grinder
        </span>
      )}
      <div className="text-2xl">{medal}</div>
      <Avatar className="h-14 w-14 border-2 border-border">
        <AvatarImage src={user.avatar} alt={user.name} />
        <AvatarFallback>{user.name.slice(0, 2)}</AvatarFallback>
      </Avatar>
      <div>
        <div className="text-sm font-semibold">{user.name}</div>
        <div className="text-[11px] text-muted-foreground">{user.handle}</div>
      </div>
      <div className="inline-flex items-center gap-1 rounded-full bg-brand-soft px-2 py-0.5 text-[10px] font-semibold text-brand">
        Lvl {user.level} · {user.levelName}
      </div>
      <div className="flex flex-wrap items-center justify-center gap-1">
        {user.tech.map((t) => (
          <span key={t} className="rounded border border-border bg-muted/40 px-1 py-0.5 text-[9px] font-medium text-muted-foreground">
            {t}
          </span>
        ))}
      </div>
      <div className="tnum text-lg font-semibold">{user.xp.toLocaleString()}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">XP</div>
    </motion.div>
  );
}

function Delta({ delta }: { delta: number }) {
  if (delta === 0)
    return (
      <span className="inline-flex items-center gap-0.5 text-[10px] text-muted-foreground">
        <Minus className="h-3 w-3" />0
      </span>
    );
  const up = delta > 0;
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-[10px] font-medium", up ? "text-brand" : "text-[oklch(0.65_0.22_25)]")}>
      {up ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
      {Math.abs(delta)}
    </span>
  );
}

function Row({ user }: { user: (typeof LEADERBOARD)[number] }) {
  return (
    <li className="grid grid-cols-[40px_1fr_auto] items-center gap-3 border-b border-border/60 px-4 py-2.5 transition-colors last:border-0 hover:bg-muted/30 sm:grid-cols-[48px_1fr_80px_80px_80px_60px] sm:px-5">
      <div className="flex items-center gap-1.5">
        <span className="tnum text-sm font-semibold text-muted-foreground">{user.rank}</span>
        <Delta delta={user.delta} />
      </div>
      <div className="flex min-w-0 items-center gap-2.5">
        <BuilderHoverCard user={user}>
          <Avatar className="h-8 w-8 border border-border">
            <AvatarImage src={user.avatar} alt={user.name} />
            <AvatarFallback>{user.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="truncate text-sm font-medium hover:text-brand hover:underline">{user.name}</div>
            <div className="truncate text-[11px] text-muted-foreground">
              {user.handle} · Lvl {user.level}
            </div>
          </div>
        </BuilderHoverCard>
      </div>
      <div className="flex items-center gap-3 sm:hidden">
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <Flame className="h-3 w-3" />
          <span className="tnum font-medium text-foreground">{user.streak}</span>
        </div>
        <span className="tnum text-sm font-semibold">{user.xp.toLocaleString()}</span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm">{user.commits.toLocaleString()}</span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm">{user.solved}</span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="inline-flex items-center gap-1 text-sm">
          <Flame className="h-3.5 w-3.5 text-[oklch(0.65_0.2_25)]" />
          <span className="tnum">{user.streak}</span>
        </span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm font-semibold">{user.xp.toLocaleString()}</span>
      </div>
    </li>
  );
}

function YourRow() {
  return (
    <li className="grid grid-cols-[40px_1fr_auto] items-center gap-3 border-t-2 border-brand/30 bg-brand-soft/40 px-4 py-3 sm:grid-cols-[48px_1fr_80px_80px_80px_60px] sm:px-5">
      <div className="flex items-center gap-1.5">
        <span className="tnum text-sm font-bold text-brand">{ME.rank}</span>
        <Delta delta={3} />
      </div>
      <div className="flex min-w-0 items-center gap-2.5">
        <Avatar className="h-8 w-8 border-2 border-brand">
          <AvatarImage src={ME.avatar} alt={ME.name} />
          <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <div className="truncate text-sm font-semibold">
            {ME.name} <span className="font-normal text-brand">(you)</span>
          </div>
          <div className="truncate text-[11px] text-muted-foreground">
            {ME.handle} · Lvl {ME.level}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3 sm:hidden">
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <Flame className="h-3 w-3" />
          <span className="tnum font-medium text-foreground">{ME.streak}</span>
        </div>
        <span className="tnum text-sm font-semibold text-brand">
          {ME.xp.toLocaleString()}
        </span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm">{ME.totalCommits.toLocaleString()}</span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm">{ME.dsaSolved}</span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="inline-flex items-center gap-1 text-sm">
          <Crown className="h-3.5 w-3.5 text-brand" />
          <span className="tnum">{ME.streak}</span>
        </span>
      </div>
      <div className="hidden text-right sm:block">
        <span className="tnum text-sm font-bold text-brand">
          {ME.xp.toLocaleString()}
        </span>
      </div>
    </li>
  );
}
