"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Phone, Search, Send, Video } from "lucide-react";
import { DM_THREADS, ME } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

type Thread = (typeof DM_THREADS)[number];

export function ChatView() {
  const [activeId, setActiveId] = React.useState<string>(DM_THREADS[0].id);
  const [query, setQuery] = React.useState("");
  const [draft, setDraft] = React.useState("");
  const [typing, setTyping] = React.useState(false);
  const [localMsgs, setLocalMsgs] = React.useState<Record<string, Thread["messages"]>>(
    () => Object.fromEntries(DM_THREADS.map((t) => [t.id, t.messages])),
  );

  const active = DM_THREADS.find((t) => t.id === activeId) as Thread;
  const messages = localMsgs[activeId] ?? active.messages;

  const list = DM_THREADS.filter((t) =>
    query.trim() ? t.name.toLowerCase().includes(query.toLowerCase()) : true,
  );

  const send = () => {
    const text = draft.trim();
    if (!text) return;
    const time = new Date().toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    });
    setLocalMsgs((p) => ({
      ...p,
      [activeId]: [...(p[activeId] ?? []), { from: "me", text, time }],
    }));
    setDraft("");
    // simulate reply
    setTyping(true);
    window.setTimeout(() => {
      setLocalMsgs((p) => ({
        ...p,
        [activeId]: [
          ...(p[activeId] ?? []),
          { from: "them", text: "nice 🙌", time },
        ],
      }));
      setTyping(false);
    }, 1400);
  };

  return (
    <div className="grid h-[calc(100dvh-12.5rem)] grid-cols-1 overflow-hidden rounded-xl border border-border bg-card md:h-[calc(100dvh-7.5rem)] md:grid-cols-[300px_1fr] lg:grid-cols-[340px_1fr]">
      {/* Thread list */}
      <div
        className={cn(
          "flex flex-col border-r border-border",
          activeId && "hidden md:flex",
        )}
      >
        <div className="border-b border-border p-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search messages…"
              className="h-9 w-full rounded-lg border border-border bg-muted/40 pl-8 pr-3 text-sm placeholder:text-muted-foreground focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
            />
          </div>
        </div>
        <ul className="flex-1 overflow-y-auto scrollbar-thin">
          {list.map((t) => {
            const isActive = t.id === activeId;
            return (
              <li key={t.id}>
                <button
                  onClick={() => setActiveId(t.id)}
                  className={cn(
                    "flex w-full items-center gap-3 border-b border-border/60 px-3 py-2.5 text-left transition-colors",
                    isActive ? "bg-brand-soft/40" : "hover:bg-muted/40",
                  )}
                >
                  <div className="relative shrink-0">
                    <Avatar className="h-10 w-10 border border-border">
                      <AvatarImage src={t.avatar} alt={t.name} />
                      <AvatarFallback>{t.name.slice(0, 2)}</AvatarFallback>
                    </Avatar>
                    {t.online && (
                      <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-card bg-brand" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-semibold">{t.name}</span>
                      <span className="shrink-0 text-[10px] text-muted-foreground">{t.lastTime}</span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-[11px] text-muted-foreground">{t.lastMessage}</span>
                      {t.unread > 0 && (
                        <span className="shrink-0 rounded-full bg-brand px-1.5 py-0.5 text-[9px] font-bold text-brand-foreground">
                          {t.unread}
                        </span>
                      )}
                    </div>
                  </div>
                </button>
              </li>
            );
          })}
        </ul>
      </div>

      {/* Chat panel */}
      <div className={cn("flex flex-col", !activeId && "hidden md:flex")}>
        {/* Chat header */}
        <div className="flex items-center gap-3 border-b border-border px-3 py-2.5 sm:px-4">
          <button
            onClick={() => setActiveId("")}
            className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted md:hidden"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <Avatar className="h-9 w-9 border border-border">
            <AvatarImage src={active.avatar} alt={active.name} />
            <AvatarFallback>{active.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-semibold">{active.name}</div>
            <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
              <span
                className={cn(
                  "h-1.5 w-1.5 rounded-full",
                  active.online ? "bg-brand" : "bg-muted-foreground/50",
                )}
              />
              {active.online ? "online" : `last seen ${active.lastTime} ago`}
            </div>
          </div>
          <button className="hidden h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted sm:flex" aria-label="Call">
            <Phone className="h-4 w-4" />
          </button>
          <button className="hidden h-8 w-8 items-center justify-center rounded-md text-muted-foreground hover:bg-muted sm:flex" aria-label="Video">
            <Video className="h-4 w-4" />
          </button>
        </div>

        {/* Messages */}
        <div className="flex-1 space-y-3 overflow-y-auto scrollbar-thin p-3 sm:p-4">
          {messages.map((m, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.2 }}
              className={cn("flex items-end gap-2", m.from === "me" && "justify-end")}
            >
              {m.from === "them" && (
                <Avatar className="h-6 w-6 border border-border">
                  <AvatarImage src={active.avatar} alt={active.name} />
                  <AvatarFallback>{active.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
              )}
              <div
                className={cn(
                  "max-w-[75%] rounded-2xl px-3 py-2 text-sm",
                  m.from === "me"
                    ? "rounded-br-sm bg-brand text-brand-foreground"
                    : "rounded-bl-sm bg-muted text-foreground",
                )}
              >
                <div className="leading-snug">{m.text}</div>
                <div
                  className={cn(
                    "mt-0.5 text-right text-[9px]",
                    m.from === "me" ? "text-brand-foreground/60" : "text-muted-foreground",
                  )}
                >
                  {m.time}
                </div>
              </div>
            </motion.div>
          ))}
          <AnimatePresence>
            {typing && (
              <motion.div
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="flex items-end gap-2"
              >
                <Avatar className="h-6 w-6 border border-border">
                  <AvatarImage src={active.avatar} alt={active.name} />
                  <AvatarFallback>{active.name.slice(0, 2)}</AvatarFallback>
                </Avatar>
                <div className="rounded-2xl rounded-bl-sm bg-muted px-3 py-2.5">
                  <span className="flex gap-1">
                    {[0, 1, 2].map((d) => (
                      <motion.span
                        key={d}
                        className="h-1.5 w-1.5 rounded-full bg-muted-foreground"
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ duration: 1, repeat: Infinity, delay: d * 0.18 }}
                      />
                    ))}
                  </span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Composer */}
        <div className="border-t border-border p-3">
          <div className="flex items-center gap-2">
            <input
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder={`Message ${active.name.split(" ")[0]}…`}
              className="h-10 flex-1 rounded-lg border border-border bg-muted/40 px-3 text-sm placeholder:text-muted-foreground focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
            />
            <button
              onClick={send}
              disabled={!draft.trim()}
              className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand text-brand-foreground transition-colors hover:bg-brand/90 disabled:opacity-40"
              aria-label="Send"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
          <div className="mt-1.5 px-1 text-[10px] text-muted-foreground">
            Signed in as {ME.handle} · messages are end-to-end sample data
          </div>
        </div>
      </div>
    </div>
  );
}
