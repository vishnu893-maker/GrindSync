"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Calendar,
  Github,
  Link2,
  MapPin,
  Pencil,
  Share2,
} from "lucide-react";
import { ME, SKILL_BREAKDOWN } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ContributionGraph } from "../widgets/contribution-graph";
import { Badges } from "../widgets/badges";
import { ActivityFeed } from "../widgets/activity-feed";
import { cn } from "@/lib/utils";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "badges", label: "Badges" },
  { id: "activity", label: "Activity" },
] as const;

const STATS = [
  { label: "Commits", value: ME.totalCommits.toLocaleString() },
  { label: "Solved", value: `${ME.dsaSolved}` },
  { label: "Streak", value: `${ME.streak}d` },
  { label: "Rank", value: `#${ME.rank}` },
  { label: "XP", value: ME.xp.toLocaleString() },
  { label: "Level", value: `${ME.level}` },
];

export function ProfileView() {
  const [tab, setTab] = React.useState<(typeof TABS)[number]["id"]>("overview");

  return (
    <div className="flex flex-col gap-5">
      {/* Banner + identity */}
      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="h-28 w-full sm:h-36" style={{ background: ME.banner }} />
        <div className="px-4 pb-4 sm:px-6">
          <div className="-mt-10 flex flex-col gap-3 sm:-mt-12 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-end gap-3">
              <Avatar className="h-20 w-20 shrink-0 border-4 border-card">
                <AvatarImage src={ME.avatar} alt={ME.name} />
                <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <div className="pb-1">
                <h2 className="text-xl font-semibold tracking-tight sm:text-2xl">
                  {ME.name}
                </h2>
                <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-muted-foreground">
                  <span>{ME.handle}</span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-brand-soft px-1.5 py-0.5 text-[10px] font-semibold text-brand">
                    Lvl {ME.level} · {ME.levelName}
                  </span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="h-8">
                <Share2 className="h-3.5 w-3.5" />
                Share
              </Button>
              <Button size="sm" className="h-8 bg-brand text-brand-foreground hover:bg-brand/90">
                <Pencil className="h-3.5 w-3.5" />
                Edit
              </Button>
            </div>
          </div>

          <p className="mt-4 max-w-2xl text-sm text-foreground/90">{ME.bio}</p>

          <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1">
              <MapPin className="h-3.5 w-3.5" />
              {ME.location}
            </span>
            <span className="inline-flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" />
              Joined {ME.joined}
            </span>
            <a className="inline-flex items-center gap-1 hover:text-foreground" href="#">
              <Github className="h-3.5 w-3.5" />
              {ME.githubUsername}
            </a>
            <a className="inline-flex items-center gap-1 hover:text-foreground" href="#">
              <Link2 className="h-3.5 w-3.5" />
              leetcode/{ME.leetcodeUsername}
            </a>
          </div>
        </div>
      </div>

      {/* Stat strip */}
      <div className="grid grid-cols-3 gap-px overflow-hidden rounded-xl border border-border bg-border sm:grid-cols-6">
        {STATS.map((s) => (
          <div key={s.label} className="bg-card px-3 py-3 text-center">
            <div className="tnum text-lg font-semibold sm:text-xl">{s.value}</div>
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">
              {s.label}
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 rounded-lg border border-border bg-muted/40 p-1 w-full sm:w-auto sm:inline-flex">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              "relative flex-1 rounded-md px-3 py-1.5 text-xs font-medium transition-colors sm:flex-none",
              tab === t.id ? "text-background" : "text-muted-foreground hover:text-foreground",
            )}
          >
            {tab === t.id && (
              <motion.span
                layoutId="profile-tab"
                className="absolute inset-0 rounded-md bg-brand"
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}
            <span className="relative z-10">{t.label}</span>
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <motion.div
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 gap-3 lg:grid-cols-3"
        >
          <div className="lg:col-span-2">
            <ContributionGraph />
          </div>
          <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4">
            <div className="text-xs font-medium text-muted-foreground">
              Skill breakdown
            </div>
            <div className="flex flex-col gap-3">
              {SKILL_BREAKDOWN.map((s, i) => (
                <div key={s.skill}>
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-medium">{s.skill}</span>
                    <span className="text-muted-foreground">
                      <span className="tnum font-semibold text-foreground">{s.solved}</span>{" "}
                      solved · <span className="tnum">{s.pct}%</span>
                    </span>
                  </div>
                  <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${s.pct}%` }}
                      transition={{ duration: 0.7, delay: i * 0.06 }}
                      className="h-full rounded-full bg-brand"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {tab === "overview" && (
        <div>
          <div className="mb-2 text-xs font-medium text-muted-foreground">
            Earned badges
          </div>
          <Badges />
        </div>
      )}

      {tab === "badges" && <Badges />}

      {tab === "activity" && (
        <div className="max-w-2xl">
          <ActivityFeed />
        </div>
      )}
    </div>
  );
}
