"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Check, Clock, Crown, Search, Users } from "lucide-react";
import { ACTIVE_CHALLENGES } from "../data";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const FILTERS = [
  { id: "all", label: "All" },
  { id: "joined", label: "Joined" },
  { id: "DSA", label: "DSA" },
  { id: "Design", label: "Design" },
  { id: "Build", label: "Build" },
  { id: "OSS", label: "OSS" },
] as const;

const diffStyle: Record<string, string> = {
  Hard: "text-[oklch(0.65_0.22_25)] bg-[oklch(0.65_0.22_25/0.12)]",
  Medium: "text-[oklch(0.75_0.15_80)] bg-[oklch(0.75_0.15_80/0.12)]",
  Easy: "text-brand bg-brand-soft",
};

export function ChallengesView() {
  const [filter, setFilter] = React.useState<string>("all");
  const [query, setQuery] = React.useState("");

  const list = ACTIVE_CHALLENGES.filter((c) => {
    if (filter === "joined") return c.joined;
    if (filter === "all") return true;
    return c.tag === filter;
  }).filter((c) =>
    query.trim() ? c.title.toLowerCase().includes(query.toLowerCase()) : true,
  );

  return (
    <div className="flex flex-col gap-5">
      {/* Search + filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search challenges…"
            className="h-9 w-full rounded-lg border border-border bg-muted/40 pl-8 pr-3 text-sm placeholder:text-muted-foreground focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-border bg-muted/40 p-1">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={cn(
                "relative rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                filter === f.id ? "text-background" : "text-muted-foreground hover:text-foreground",
              )}
            >
              {filter === f.id && (
                <motion.span
                  layoutId="ch-filter"
                  className="absolute inset-0 rounded-md bg-brand"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
              <span className="relative z-10">{f.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((c, i) => (
          <motion.article
            key={c.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: i * 0.04 }}
            className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 transition-colors hover:border-border/80"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="rounded-md border border-border bg-muted/40 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {c.tag}
                </span>
                {c.joined && (
                  <span className="inline-flex items-center gap-1 rounded-md bg-brand-soft px-1.5 py-0.5 text-[9px] font-semibold text-brand">
                    <Check className="h-2.5 w-2.5" /> Joined
                  </span>
                )}
              </div>
              <span className={cn("rounded px-1.5 py-0.5 text-[9px] font-semibold", diffStyle[c.difficulty])}>
                {c.difficulty}
              </span>
            </div>

            <h3 className="text-sm font-semibold leading-snug">{c.title}</h3>

            {c.joined && c.progress < 100 && (
              <div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span className="tnum">{c.progress}%</span>
                  <span className="tnum">+{c.reward} XP</span>
                </div>
                <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${c.progress}%` }}
                    transition={{ duration: 0.7, delay: 0.1 + i * 0.04 }}
                    className="h-full rounded-full bg-brand"
                  />
                </div>
              </div>
            )}
            {c.progress === 100 && (
              <div className="flex items-center gap-1.5 rounded-md bg-brand-soft px-2 py-1.5 text-[11px] font-medium text-brand">
                <Crown className="h-3.5 w-3.5" /> Completed · +{c.reward} XP earned
              </div>
            )}

            <div className="mt-auto flex items-center justify-between border-t border-border pt-3">
              <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                <Users className="h-3 w-3" />
                <span className="tnum">{c.participants.toLocaleString()}</span> builders
              </div>
              <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
                <Clock className="h-3 w-3" />
                <span className="tnum">{c.daysLeft}d left</span>
              </div>
            </div>

            <Button
              variant={c.joined ? "outline" : "default"}
              size="sm"
              className={cn(
                "h-8 w-full text-xs",
                !c.joined && "bg-brand text-brand-foreground hover:bg-brand/90",
              )}
            >
              {c.progress === 100
                ? "View results"
                : c.joined
                  ? "Continue"
                  : "Join challenge"}
            </Button>
          </motion.article>
        ))}
      </div>

      {list.length === 0 && (
        <div className="rounded-xl border border-dashed border-border py-16 text-center text-sm text-muted-foreground">
          No challenges match your filter.
        </div>
      )}
    </div>
  );
}
