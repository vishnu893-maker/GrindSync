"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, Lock, RefreshCw } from "lucide-react";
import { ProfileCard } from "./widgets/profile-card";
import { CommitChart } from "./widgets/commit-chart";
import { XpBreakdown } from "./widgets/xp-breakdown";
import { DailyDsa } from "./widgets/daily-dsa";
import { MiniLeaderboard } from "./widgets/mini-leaderboard";
import { ActiveChallenges } from "./widgets/active-challenges";
import { OnlineBuilders } from "./widgets/online-builders";
import { ME } from "./data";
import { cn } from "@/lib/utils";

const TABS = [
  { id: "overview", label: "Overview" },
  { id: "network", label: "Network" },
] as const;

type TabId = (typeof TABS)[number]["id"];

export function DashboardPreview() {
  const [tab, setTab] = React.useState<TabId>("overview");

  return (
    <section
      id="dashboard"
      className="scroll-mt-20 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section heading */}
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-wider text-brand">
            Live dashboard
          </span>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Your grind, on one screen.
          </h2>
          <p className="mt-3 text-balance text-sm text-muted-foreground sm:text-base">
            Commits, problems, streaks and rank — synced automatically from the
            tools you already use. No manual entry, ever.
          </p>
        </div>

        {/* Window chrome */}
        <div className="mt-10 overflow-hidden rounded-2xl border border-border bg-card shadow-xl shadow-foreground/5">
          {/* Title bar */}
          <div className="flex items-center justify-between gap-3 border-b border-border bg-muted/30 px-3 py-2.5 sm:px-4">
            <div className="flex items-center gap-1.5">
              <span className="h-3 w-3 rounded-full bg-[oklch(0.65_0.22_25)]" />
              <span className="h-3 w-3 rounded-full bg-[oklch(0.75_0.15_80)]" />
              <span className="h-3 w-3 rounded-full bg-brand" />
            </div>

            {/* Fake URL bar */}
            <div className="mx-auto flex h-7 w-full max-w-md items-center justify-center gap-1.5 rounded-md border border-border bg-background px-3 text-[11px] font-medium text-muted-foreground">
              <Lock className="h-3 w-3" />
              <span className="truncate">grindsync.app/dashboard</span>
            </div>

            <div className="flex items-center gap-1">
              <button
                aria-label="Refresh"
                className="hidden h-6 w-6 items-center justify-center rounded text-muted-foreground hover:bg-muted sm:inline-flex"
              >
                <RefreshCw className="h-3.5 w-3.5" />
              </button>
              <span className="hidden text-[11px] text-muted-foreground sm:inline">
                {new Date().toLocaleDateString("en-US", {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                })}
              </span>
            </div>
          </div>

          {/* Toolbar with tabs + user chip */}
          <div className="flex items-center justify-between gap-3 border-b border-border bg-background/40 px-3 py-2 sm:px-4">
            <div className="flex items-center gap-1">
              {TABS.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "relative rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                    tab === t.id
                      ? "text-foreground"
                      : "text-muted-foreground hover:text-foreground",
                  )}
                >
                  {tab === t.id && (
                    <motion.span
                      layoutId="dash-tab-active"
                      className="absolute inset-0 rounded-md bg-muted"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                  <span className="relative z-10">{t.label}</span>
                </button>
              ))}
            </div>
            <div className="hidden items-center gap-1.5 text-[11px] text-muted-foreground sm:flex">
              <span className="tnum">{ME.rank}</span>
              <span>·</span>
              <span>global rank</span>
              <ArrowUpRight className="h-3 w-3 text-brand" />
            </div>
          </div>

          {/* Dashboard body */}
          <div className="bg-background p-3 sm:p-4 lg:p-5">
            <AnimatePresence mode="wait">
              {tab === "overview" ? (
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.25 }}
                  className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3"
                >
                  <ProfileCard />
                  <CommitChart />
                  <DailyDsa />
                  <XpBreakdown />
                  <div className="sm:col-span-2 lg:col-span-2">
                    <MiniLeaderboard />
                  </div>
                  <div className="sm:col-span-2 lg:col-span-1">
                    <ActiveChallenges />
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="network"
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.25 }}
                  className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3"
                >
                  <div className="sm:col-span-1">
                    <OnlineBuilders />
                  </div>
                  <div className="sm:col-span-2 lg:col-span-2">
                    <ActiveChallenges />
                  </div>
                  <div className="sm:col-span-2 lg:col-span-3">
                    <MiniLeaderboard />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          Interactive preview · data shown is sample
        </p>
      </div>
    </section>
  );
}
