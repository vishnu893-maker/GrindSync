// Realistic mock data for GrindSync. Shared by landing + signed-in app.

export const ME = {
  name: "Aarav Mehta",
  username: "aarav.dev",
  handle: "@aarav",
  email: "aarav@grindsync.app",
  avatar: "https://i.pravatar.cc/160?img=12",
  banner:
    "linear-gradient(120deg, oklch(0.28 0.06 160), oklch(0.22 0.05 200) 60%, oklch(0.2 0.04 95))",
  level: 14,
  levelName: "Architect",
  xp: 4820,
  xpToNext: 6500,
  rank: 7,
  streak: 23,
  totalCommits: 1247,
  dsaSolved: 312,
  codingTimeWeek: "31h 14m",
  githubUsername: "aarav-dev",
  leetcodeUsername: "aaravdev",
  joined: "Mar 2024",
  bio: "Backend & systems · shipping in public. Currently obsessed with distributed queues and clean APIs.",
  location: "Bengaluru, IN",
};

export const HERO_TICKER = [
  { label: "commits synced today", value: "184,920" },
  { label: "problems solved", value: "52,318" },
  { label: "builders online", value: "1,204" },
  { label: "XP awarded", value: "9.1M" },
];

export const WEEK_COMMITS = [
  { day: "Mon", commits: 6, label: "Mon" },
  { day: "Tue", commits: 11, label: "Tue" },
  { day: "Wed", commits: 4, label: "Wed" },
  { day: "Thu", commits: 9, label: "Thu" },
  { day: "Fri", commits: 14, label: "Fri" },
  { day: "Sat", commits: 7, label: "Sat" },
  { day: "Sun", commits: 3, label: "Sun" },
];

export const XP_BUDGET = [
  { source: "GitHub commits", xp: 420, color: "var(--chart-1)" },
  { source: "DSA solved", xp: 280, color: "var(--chart-3)" },
  { source: "Daily streak", xp: 165, color: "var(--chart-2)" },
  { source: "Challenges", xp: 110, color: "var(--chart-5)" },
];

export const DAILY_DSA = {
  id: 1847,
  title: "Longest Substring with At Most K Distinct Characters",
  difficulty: "Hard",
  acRate: 38.4,
  tags: ["Sliding Window", "Hash Map", "Two Pointers"],
  url: "https://leetcode.com/problems/longest-substring-with-at-most-k-distinct-characters/",
};

export const LEADERBOARD = [
  { rank: 1, name: "Ishita Rao", handle: "@ishita", avatar: "https://i.pravatar.cc/120?img=47", xp: 9820, streak: 91, level: 22, levelName: "Mythic", commits: 3420, solved: 891, delta: 2, tech: ["Go", "Rust", "Postgres"] },
  { rank: 2, name: "Devansh Kapoor", handle: "@devansh", avatar: "https://i.pravatar.cc/120?img=68", xp: 9240, streak: 64, level: 21, levelName: "Mythic", commits: 2890, solved: 778, delta: -1, tech: ["TypeScript", "Next.js", "AWS"] },
  { rank: 3, name: "Meera Nair", handle: "@meera.dev", avatar: "https://i.pravatar.cc/120?img=32", xp: 8710, streak: 47, level: 20, levelName: "Grandmaster", commits: 2410, solved: 712, delta: 0, tech: ["Python", "PyTorch", "CUDA"] },
  { rank: 4, name: "Kabir Sethi", handle: "@kabir", avatar: "https://i.pravatar.cc/120?img=15", xp: 7990, streak: 38, level: 18, levelName: "Grandmaster", commits: 1980, solved: 645, delta: 3, tech: ["Rust", "WebAssembly", "Solidity"] },
  { rank: 5, name: "Ananya Iyer", handle: "@ananya", avatar: "https://i.pravatar.cc/120?img=20", xp: 7420, streak: 52, level: 17, levelName: "Master", commits: 1740, solved: 612, delta: 1, tech: ["Kotlin", "Android", "Compose"] },
  { rank: 6, name: "Rohan Verma", handle: "@rohanv", avatar: "https://i.pravatar.cc/120?img=53", xp: 6710, streak: 29, level: 16, levelName: "Master", commits: 1520, solved: 540, delta: -2, tech: ["Node", "GraphQL", "Redis"] },
];

export const ACTIVE_CHALLENGES = [
  { id: "c1", title: "30 Days of System Design", participants: 1284, reward: 1200, difficulty: "Hard", daysLeft: 11, progress: 63, tag: "Design", joined: true },
  { id: "c2", title: "Ship a CLI in public", participants: 642, reward: 800, difficulty: "Medium", daysLeft: 6, progress: 40, tag: "Build", joined: true },
  { id: "c3", title: "Graph theory sprint", participants: 938, reward: 600, difficulty: "Medium", daysLeft: 14, progress: 21, tag: "DSA", joined: false },
  { id: "c4", title: "Open-source contributor", participants: 410, reward: 500, difficulty: "Easy", daysLeft: 20, progress: 0, tag: "OSS", joined: false },
  { id: "c5", title: "Database internals", participants: 312, reward: 1500, difficulty: "Hard", daysLeft: 25, progress: 0, tag: "Design", joined: false },
  { id: "c6", title: "Daily LeetCode grind", participants: 2104, reward: 300, difficulty: "Easy", daysLeft: 4, progress: 100, tag: "DSA", joined: true },
];

export const ONLINE_BUILDERS = [
  { name: "Ishita Rao", handle: "@ishita", avatar: "https://i.pravatar.cc/80?img=47", status: "shipping", activity: "commit on grindsync-cli", tech: ["Go", "Rust"] },
  { name: "Kabir Sethi", handle: "@kabir", avatar: "https://i.pravatar.cc/80?img=15", status: "grinding", activity: "LeetCode #1847", tech: ["Rust", "WASM"] },
  { name: "Meera Nair", handle: "@meera.dev", avatar: "https://i.pravatar.cc/80?img=32", status: "online", activity: "reviewing PRs", tech: ["Python", "PyTorch"] },
  { name: "Ananya Iyer", handle: "@ananya", avatar: "https://i.pravatar.cc/80?img=20", status: "grinding", activity: "system design", tech: ["Kotlin"] },
  { name: "Rohan Verma", handle: "@rohanv", avatar: "https://i.pravatar.cc/80?img=53", status: "online", activity: "debugging", tech: ["Node", "Redis"] },
];

export const FEATURES = [
  { id: "auto-sync", title: "Auto-synced proof of work", description: "Connect GitHub and LeetCode once. Every commit, PR and solved problem flows into your verified profile — no manual logging, no resume padding.", bullets: ["GitHub commits & PRs", "LeetCode solutions", "Coding time via WakaTime"], accent: "var(--chart-1)" },
  { id: "xp", title: "XP that reflects real effort", description: "A weighted scoring model rewards consistency over hype. Daily streaks, deep-work hours and problem difficulty all feed a level you can trust.", bullets: ["Weighted scoring", "Streak multipliers", "Named tiers"], accent: "var(--chart-3)" },
  { id: "leaderboard", title: "Leaderboards worth climbing", description: "Filter by week, month or all-time. See who's actually shipping — not who's posting the most. Your rank updates the moment your work lands.", bullets: ["Weekly / monthly / all-time", "Friends & global", "Live rank deltas"], accent: "var(--chart-2)" },
  { id: "challenges", title: "Challenges that end tutorial hell", description: "Daily DSA prompts, build-in-public sprints and system design tracks. Auto-verified completion — solve it, and the XP is yours.", bullets: ["Daily DSA", "Build sprints", "System design tracks"], accent: "var(--chart-5)" },
  { id: "network", title: "A network of real builders", description: "Follow developers whose work you respect. See what they're shipping in real time. Find contributors by verified tech stack, not vanity metrics.", bullets: ["Live activity feed", "Verified stacks", "Contributor search"], accent: "var(--chart-4)" },
  { id: "identity", title: "A living résumé", description: "Your GrindSync profile is proof you can show employers, not tell them. Real commits, real problems, real streaks — all verifiable.", bullets: ["Verifiable history", "Embeddable cards", "Public stats API"], accent: "var(--chart-1)" },
];

export const STATS = [
  { value: "52,318", label: "problems solved", sub: "across the network" },
  { value: "1.2M+", label: "commits synced", sub: "from real repos" },
  { value: "184K", label: "daily grinders", sub: "online right now" },
  { value: "9.1M", label: "XP awarded", sub: "for real work" },
];

// ── Signed-in app data ──────────────────────────────────────────────

// 52-week contribution heatmap. Deterministic pseudo-random for realism.
export const CONTRIBUTION_GRAPH: number[][] = (() => {
  const weeks: number[][] = [];
  let seed = 7;
  const rand = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };
  for (let w = 0; w < 52; w++) {
    const days: number[] = [];
    for (let d = 0; d < 7; d++) {
      const r = rand();
      // ramp up toward "now" so recent weeks look hotter
      const ramp = 0.3 + (w / 52) * 0.7;
      const v = r * ramp;
      let level = 0;
      if (v > 0.18) level = 1;
      if (v > 0.36) level = 2;
      if (v > 0.55) level = 3;
      if (v > 0.72) level = 4;
      days.push(level);
    }
    weeks.push(days);
  }
  return weeks;
})();

export const ACTIVITY_FEED = [
  { type: "commit", title: "Pushed 4 commits to grindsync-cli/main", detail: "feat(queue): backpressure-aware consumer", time: "12m ago", xp: 40 },
  { type: "dsa", title: "Solved LeetCode #1847 (Hard)", detail: "Longest Substring with At Most K Distinct", time: "1h ago", xp: 150 },
  { type: "challenge", title: "Completed “Daily LeetCode grind”", detail: "Day 23 streak · +streak bonus", time: "1h ago", xp: 30 },
  { type: "follow", title: "Ishita Rao followed you back", detail: "You can now DM each other", time: "3h ago", xp: 0 },
  { type: "commit", title: "Opened PR #284 on grindsync/web", detail: "fix(dashboard): heatmap tooltip overflow", time: "5h ago", xp: 20 },
  { type: "level", title: "Reached Level 14 — Architect", detail: "Unlocked the verified-tiers badge", time: "yesterday", xp: 0 },
  { type: "dsa", title: "Solved LeetCode #1840 (Medium)", detail: "Minimum Number of Operations", time: "yesterday", xp: 80 },
  { type: "commit", title: "Pushed 9 commits to personal/portfolio", detail: "chore: redesign case studies", time: "2d ago", xp: 90 },
];

export const BADGES = [
  { id: "b1", name: "Streakkeeper", desc: "20+ day streak", icon: "flame", earned: true, rarity: "rare" },
  { id: "b2", name: "Century", desc: "100 commits synced", icon: "commit", earned: true, rarity: "common" },
  { id: "b3", name: "Hard hitter", desc: "Solve 25 Hard problems", icon: "sword", earned: true, rarity: "rare" },
  { id: "b4", name: "Open sourcerer", desc: "Merge an OSS PR", icon: "git", earned: true, rarity: "epic" },
  { id: "b5", name: "Night owl", desc: "Ship after midnight 10×", icon: "moon", earned: true, rarity: "common" },
  { id: "b6", name: "Architect", desc: "Reach level 14", icon: "crown", earned: true, rarity: "epic" },
  { id: "b7", name: "Mythic", desc: "Reach level 22", icon: "trophy", earned: false, rarity: "legendary" },
  { id: "b8", name: "365", desc: "A full year streak", icon: "calendar", earned: false, rarity: "legendary" },
];

export const DM_THREADS = [
  {
    id: "t1",
    name: "Ishita Rao",
    handle: "@ishita",
    avatar: "https://i.pravatar.cc/80?img=47",
    online: true,
    unread: 2,
    lastMessage: "wait the backpressure approach is clean, ship it",
    lastTime: "2m",
    messages: [
      { from: "them", text: "yo, saw your PR on the queue consumer 👀", time: "10:02" },
      { from: "me", text: "yeah finally cracked the backpressure thing", time: "10:04" },
      { from: "them", text: "the bounded channel + drop-oldest combo?", time: "10:04" },
      { from: "me", text: "exactly. keeps memory flat even under burst", time: "10:05" },
      { from: "them", text: "wait the backpressure approach is clean, ship it", time: "10:06" },
      { from: "them", text: "also can you review my retry logic when you get a sec?", time: "10:06" },
    ],
  },
  {
    id: "t2",
    name: "Meera Nair",
    handle: "@meera.dev",
    avatar: "https://i.pravatar.cc/80?img=32",
    online: true,
    unread: 0,
    lastMessage: "thanks for the CUDA pointers, got 3x throughput",
    lastTime: "1h",
    messages: [
      { from: "me", text: "try coalescing the memory access per warp", time: "09:20" },
      { from: "them", text: "thanks for the CUDA pointers, got 3x throughput 🙏", time: "09:40" },
    ],
  },
  {
    id: "t3",
    name: "Kabir Sethi",
    handle: "@kabir",
    avatar: "https://i.pravatar.cc/80?img=15",
    online: false,
    unread: 0,
    lastMessage: "remind me to show you the WASM benchmark",
    lastTime: "1d",
    messages: [
      { from: "them", text: "remind me to show you the WASM benchmark", time: "Yesterday" },
    ],
  },
  {
    id: "t4",
    name: "Devansh Kapoor",
    handle: "@devansh",
    avatar: "https://i.pravatar.cc/80?img=68",
    online: false,
    unread: 0,
    lastMessage: "gg on the leaderboard climb 🚀",
    lastTime: "2d",
    messages: [{ from: "them", text: "gg on the leaderboard climb 🚀", time: "Mon" }],
  },
];

export const DISCOVER_BUILDERS = [
  { name: "Ishita Rao", handle: "@ishita", avatar: "https://i.pravatar.cc/120?img=47", level: 22, levelName: "Mythic", streak: 91, tech: ["Go", "Rust", "Postgres"], followers: "12.4k", mutual: 8 },
  { name: "Meera Nair", handle: "@meera.dev", avatar: "https://i.pravatar.cc/120?img=32", level: 20, levelName: "Grandmaster", streak: 47, tech: ["Python", "PyTorch"], followers: "8.9k", mutual: 5 },
  { name: "Kabir Sethi", handle: "@kabir", avatar: "https://i.pravatar.cc/120?img=15", level: 18, levelName: "Grandmaster", streak: 38, tech: ["Rust", "WASM", "Solidity"], followers: "6.1k", mutual: 3 },
  { name: "Ananya Iyer", handle: "@ananya", avatar: "https://i.pravatar.cc/120?img=20", level: 17, levelName: "Master", streak: 52, tech: ["Kotlin", "Compose"], followers: "4.7k", mutual: 2 },
  { name: "Rohan Verma", handle: "@rohanv", avatar: "https://i.pravatar.cc/120?img=53", level: 16, levelName: "Master", streak: 29, tech: ["Node", "GraphQL", "Redis"], followers: "3.2k", mutual: 1 },
  { name: "Sara Khan", handle: "@sara.k", avatar: "https://i.pravatar.cc/120?img=29", level: 15, levelName: "Master", streak: 33, tech: ["Swift", "iOS"], followers: "2.8k", mutual: 4 },
];

export const NOTIFICATIONS = [
  { id: "n1", type: "follow", text: "Ishita Rao followed you back", time: "3h ago", read: false },
  { id: "n2", type: "challenge", text: "Day 23 streak — keep it alive today", time: "5h ago", read: false },
  { id: "n3", type: "xp", text: "You earned +150 XP for solving #1847", time: "1h ago", read: false },
  { id: "n4", type: "rank", text: "You moved up 3 spots to rank #7", time: "2h ago", read: true },
  { id: "n5", type: "system", text: "New: System design tracks are live", time: "1d ago", read: true },
];

export const SKILL_BREAKDOWN = [
  { skill: "Algorithms", solved: 142, pct: 78 },
  { skill: "Data Structures", solved: 98, pct: 64 },
  { skill: "Dynamic Prog.", solved: 31, pct: 41 },
  { skill: "Graphs", solved: 27, pct: 55 },
  { skill: "System Design", solved: 14, pct: 33 },
];

// 7-day sparkline trends for the dashboard stat cards
export const STAT_TRENDS = {
  xp: [42, 78, 55, 120, 96, 140, 168],
  commits: [4, 11, 6, 9, 14, 7, 8],
  streak: [17, 18, 19, 20, 21, 22, 23],
  rank: [12, 11, 11, 10, 9, 8, 7],
};

// Weekly XP goal for the dashboard progress ring
export const WEEKLY_GOAL = {
  current: 975,
  target: 1500,
  label: "Weekly XP goal",
};

// Today's focus checklist
export const TODAY_FOCUS = [
  { id: "f1", text: "Solve today's DSA (#1847)", done: false, xp: 150 },
  { id: "f2", text: "Push at least 3 commits", done: true, xp: 60 },
  { id: "f3", text: "Review 1 open PR", done: false, xp: 40 },
  { id: "f4", text: "Keep the streak alive", done: false, xp: 30 },
];
