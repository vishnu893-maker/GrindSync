"use client";

import * as React from "react";
import { Landing } from "./landing";
import { AppShell } from "./app-shell";
import { AuthPage } from "./auth-page";

type View = "landing" | "login" | "signup" | "app";

export function Experience() {
  const [view, setView] = React.useState<View>("landing");

  switch (view) {
    case "app":
      return <AppShell onSignOut={() => setView("landing")} />;
    case "login":
      return (
        <AuthPage
          mode="login"
          onAuthed={() => setView("app")}
          onSwitchMode={() => setView("signup")}
          onBack={() => setView("landing")}
        />
      );
    case "signup":
      return (
        <AuthPage
          mode="signup"
          onAuthed={() => setView("app")}
          onSwitchMode={() => setView("login")}
          onBack={() => setView("landing")}
        />
      );
    default:
      return (
        <Landing
          onSignIn={() => setView("login")}
          onGetStarted={() => setView("signup")}
        />
      );
  }
}
