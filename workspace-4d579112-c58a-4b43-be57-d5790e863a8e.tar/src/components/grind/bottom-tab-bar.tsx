"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { LayoutGrid, Trophy, Sparkles, Home } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { id: "top", label: "Home", icon: Home, href: "#top" },
  { id: "dashboard", label: "Dashboard", icon: LayoutGrid, href: "#dashboard" },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy, href: "#leaderboard" },
  { id: "features", label: "Features", icon: Sparkles, href: "#features" },
] as const;

export function BottomTabBar() {
  const [active, setActive] = React.useState<string>("top");

  React.useEffect(() => {
    const ids = TABS.map((t) => t.id);
    const sections = ids
      .map((id) => document.getElementById(id))
      .filter(Boolean) as HTMLElement[];

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries
          .filter((e) => e.isIntersecting)
          .sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (visible[0]) {
          setActive(visible[0].target.id);
        }
      },
      { rootMargin: "-30% 0px -55% 0px", threshold: [0, 0.25, 0.5, 1] },
    );
    sections.forEach((s) => observer.observe(s));
    return () => observer.disconnect();
  }, []);

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/85 backdrop-blur-xl md:hidden"
      aria-label="Primary mobile navigation"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <ul className="mx-auto grid max-w-md grid-cols-4">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <li key={tab.id} className="relative">
              <a
                href={tab.href}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "relative flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors",
                  isActive
                    ? "text-foreground"
                    : "text-muted-foreground hover:text-foreground",
                )}
              >
                <span className="relative flex h-6 w-6 items-center justify-center">
                  <Icon
                    className={cn("h-5 w-5 transition-transform", isActive && "scale-110")}
                    strokeWidth={isActive ? 2.4 : 2}
                  />
                </span>
                <span className="tracking-tight">{tab.label}</span>
                {isActive && (
                  <motion.span
                    layoutId="bottom-tab-active"
                    className="absolute -top-px h-0.5 w-8 rounded-full bg-brand"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </a>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
