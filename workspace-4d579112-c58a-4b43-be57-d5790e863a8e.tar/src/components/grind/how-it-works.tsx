"use client";

import { motion } from "framer-motion";
import { Github, Link2, TrendingUp } from "lucide-react";

const STEPS = [
  {
    icon: Link2,
    step: "01",
    title: "Connect your accounts",
    desc: "Sign in with GitHub or Google, then link your LeetCode and WakaTime. One-time setup, under a minute.",
  },
  {
    icon: Github,
    step: "02",
    title: "We sync the rest",
    desc: "Commits, solved problems and deep-work hours flow in automatically. You never touch a form again.",
  },
  {
    icon: TrendingUp,
    step: "03",
    title: "Climb & get noticed",
    desc: "Earn XP, climb the leaderboard, and share a profile that proves what you can actually build.",
  },
];

export function HowItWorks() {
  return (
    <section className="py-12 sm:py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mb-8 text-center">
          <span className="text-xs font-semibold uppercase tracking-wider text-brand">
            How it works
          </span>
          <h2 className="mt-2 text-balance text-2xl font-semibold tracking-tight sm:text-3xl">
            Live in three steps.
          </h2>
        </div>

        <div className="relative grid grid-cols-1 gap-4 sm:grid-cols-3 sm:gap-6">
          {/* connecting line (desktop) */}
          <div
            aria-hidden
            className="absolute left-[16.6%] right-[16.6%] top-[2.6rem] hidden h-px bg-gradient-to-r from-border via-brand/40 to-border sm:block"
          />
          {STEPS.map((s, i) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.step}
                initial={{ opacity: 0, y: 12 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.4, delay: i * 0.08 }}
                className="relative flex flex-col items-center gap-3 rounded-xl border border-border bg-card p-5 text-center sm:p-6"
              >
                <div className="relative">
                  <span className="flex h-12 w-12 items-center justify-center rounded-full border border-border bg-card text-brand shadow-sm">
                    <Icon className="h-5 w-5" />
                  </span>
                  <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand px-1 text-[9px] font-bold text-brand-foreground">
                    {s.step}
                  </span>
                </div>
                <h3 className="text-base font-semibold tracking-tight">
                  {s.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {s.desc}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
