"use client";

import { TopNav } from "./top-nav";
import { BottomTabBar } from "./bottom-tab-bar";
import { Hero } from "./hero";
import { HowItWorks } from "./how-it-works";
import { DashboardPreview } from "./dashboard-preview";
import { FeaturesSection } from "./features-section";
import { LeaderboardSection } from "./leaderboard-section";
import { CTASection } from "./cta-section";
import { SiteFooter } from "./site-footer";

export function Landing({
  onSignIn,
  onGetStarted,
}: {
  onSignIn?: () => void;
  onGetStarted?: () => void;
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopNav onSignIn={onSignIn} onGetStarted={onGetStarted} />
      <main className="flex-1 pb-20 md:pb-0">
        <Hero onSignIn={onSignIn} onGetStarted={onGetStarted} />
        <HowItWorks />
        <DashboardPreview />
        <FeaturesSection />
        <LeaderboardSection />
        <CTASection onSignIn={onSignIn} onGetStarted={onGetStarted} />
      </main>
      <SiteFooter />
      <BottomTabBar />
    </div>
  );
}
