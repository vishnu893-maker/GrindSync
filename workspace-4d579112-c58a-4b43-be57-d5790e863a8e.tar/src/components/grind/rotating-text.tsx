"use client";

import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";

interface RotatingTextProps {
  words: string[];
  interval?: number;
  className?: string;
  gradientClassName?: string;
}

/**
 * Cycles through words with a vertical slide + blur transition.
 * Inspired by reactbits.dev "Text Rotate" / animate-ui text rotator.
 */
export function RotatingText({
  words,
  interval = 2200,
  className,
  gradientClassName,
}: RotatingTextProps) {
  const [index, setIndex] = React.useState(0);

  React.useEffect(() => {
    if (words.length <= 1) return;
    const id = window.setInterval(() => {
      setIndex((i) => (i + 1) % words.length);
    }, interval);
    return () => window.clearInterval(id);
  }, [words.length, interval]);

  const word = words[index] ?? "";

  return (
    <span
      className={`relative inline-flex items-baseline ${className ?? ""}`}
      style={{ minWidth: "1em" }}
    >
      <AnimatePresence mode="wait">
        <motion.span
          key={word}
          initial={{ y: "0.6em", opacity: 0, filter: "blur(6px)" }}
          animate={{ y: 0, opacity: 1, filter: "blur(0px)" }}
          exit={{ y: "-0.6em", opacity: 0, filter: "blur(6px)" }}
          transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          className={gradientClassName}
        >
          {word}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}
