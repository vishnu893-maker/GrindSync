"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Eye,
  EyeOff,
  Github,
  Loader2,
  Lock,
  Mail,
  User,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/theme-toggle";
import { ME } from "./data";
import Antigravity from "./antigravity";
import { cn } from "@/lib/utils";

type Mode = "login" | "signup";

interface AuthPageProps {
  mode: Mode;
  onAuthed: () => void;
  onSwitchMode: () => void;
  onBack: () => void;
}

export function AuthPage({
  mode,
  onAuthed,
  onSwitchMode,
  onBack,
}: AuthPageProps) {
  const isSignup = mode === "signup";

  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [confirm, setConfirm] = React.useState("");
  const [showPw, setShowPw] = React.useState(false);
  const [remember, setRemember] = React.useState(true);
  const [agree, setAgree] = React.useState(false);
  const [loading, setLoading] = React.useState(false);
  const [touched, setTouched] = React.useState<Record<string, boolean>>({});

  // validation
  const emailErr =
    email.length > 0 && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      ? "Enter a valid email"
      : "";
  const strength = scoreStrength(password);
  const pwErr =
    password.length > 0 && password.length < 8
      ? "At least 8 characters"
      : "";
  const confirmErr =
    isSignup && confirm.length > 0 && confirm !== password
      ? "Passwords don't match"
      : "";
  const nameErr = isSignup && name.length > 0 && name.length < 2 ? "Enter your name" : "";
  const termsErr = isSignup && touched.agree && !agree;

  const canSubmit =
    !emailErr &&
    !pwErr &&
    !confirmErr &&
    !nameErr &&
    email.length > 0 &&
    password.length >= 8 &&
    (!isSignup || (name.length >= 2 && confirm === password && agree));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setTouched({ email: true, password: true, name: true, confirm: true, agree: true });
    if (!canSubmit) return;
    setLoading(true);
    window.setTimeout(() => {
      setLoading(false);
      onAuthed();
    }, 1100);
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* ── Brand panel (desktop) ── */}
      <aside className="relative hidden w-1/2 overflow-hidden border-r border-border lg:block">
        <div className="absolute inset-0">
          <Antigravity
            colors={["#10b981", "#34d399", "#6ee7b7"]}
            count={500}
            particleSize={1}
            ringRadius={5}
            ambient={0.34}
            opacity={0.85}
            className="opacity-70"
          />
        </div>
        <div
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 70% 60% at 30% 50%, color-mix(in oklch, var(--background) 55%, transparent), transparent 70%)",
          }}
        />
        <div className="relative z-10 flex h-full flex-col justify-between p-10 xl:p-14">
          <button
            onClick={onBack}
            className="inline-flex h-9 w-fit items-center gap-2 rounded-lg border border-border bg-background/40 px-3 text-sm font-medium text-muted-foreground backdrop-blur-md transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to home
          </button>

          <div className="max-w-md">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-foreground text-background">
                <Zap className="h-4 w-4" strokeWidth={2.5} />
              </span>
              <span className="text-lg font-semibold tracking-tight">
                Grind<span className="text-brand">Sync</span>
              </span>
            </div>
            <h2 className="mt-8 text-balance text-3xl font-semibold leading-tight tracking-tight xl:text-4xl">
              {isSignup
                ? "Build a profile that proves what you can ship."
                : "Welcome back. The grind missed you."}
            </h2>
            <p className="mt-4 text-balance text-sm text-muted-foreground xl:text-base">
              {isSignup
                ? "Auto-track LeetCode, GitHub and coding time. Climb leaderboards with verified proof of work — not vibes."
                : "Sign in to sync today's commits, keep your streak, and see where you rank among 184k builders."}
            </p>

            <div className="mt-8 flex items-center gap-3 rounded-xl border border-border bg-background/50 p-3 backdrop-blur-md">
              <img
                src={ME.avatar}
                alt={ME.name}
                className="h-9 w-9 rounded-full border border-border"
              />
              <div className="text-xs">
                <div className="font-medium">{ME.name}</div>
                <div className="text-muted-foreground">
                  Lvl {ME.level} · {ME.streak}d streak · rank #{ME.rank}
                </div>
              </div>
              <div className="ml-auto tnum text-sm font-semibold text-brand">
                +975 XP
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6 text-xs text-muted-foreground">
            <span>
              <span className="tnum font-semibold text-foreground">1.2M+</span>{" "}
              commits synced
            </span>
            <span>
              <span className="tnum font-semibold text-foreground">184k</span>{" "}
              builders
            </span>
            <span>
              <span className="tnum font-semibold text-foreground">4.9/5</span>{" "}
              rating
            </span>
          </div>
        </div>
      </aside>

      {/* ── Form panel ── */}
      <main className="flex flex-1 flex-col">
        {/* mobile top bar */}
        <div className="flex h-16 items-center justify-between px-4 lg:hidden">
          <button
            onClick={onBack}
            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-border text-foreground"
            aria-label="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-foreground text-background">
              <Zap className="h-4 w-4" strokeWidth={2.5} />
            </span>
            <span className="text-[15px] font-semibold tracking-tight">
              Grind<span className="text-brand">Sync</span>
            </span>
          </div>
          <ThemeToggle />
        </div>

        <div className="flex flex-1 items-center justify-center px-4 py-8 sm:px-6">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="w-full max-w-sm"
          >
            {/* heading */}
            <div className="mb-6">
              <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">
                {isSignup ? "Create your account" : "Sign in"}
              </h1>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {isSignup ? (
                  <>
                    Free during open beta · No credit card needed.
                  </>
                ) : (
                  <>
                    New here?{" "}
                    <button
                      onClick={onSwitchMode}
                      className="font-medium text-brand hover:underline"
                    >
                      Create an account
                    </button>
                  </>
                )}
              </p>
            </div>

            {/* OAuth */}
            <div className="grid grid-cols-2 gap-2.5">
              <OAuthButton label="GitHub">
                <Github className="h-4 w-4" />
              </OAuthButton>
              <OAuthButton label="Google">
                <GoogleIcon />
              </OAuthButton>
            </div>

            <div className="my-5 flex items-center gap-3 text-[11px] text-muted-foreground">
              <div className="h-px flex-1 bg-border" />
              <span>or continue with email</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            {/* Form */}
            <form onSubmit={submit} className="flex flex-col gap-3.5" noValidate>
              <AnimatePresence mode="popLayout">
                {isSignup && (
                  <motion.div
                    key="name"
                    initial={{ opacity: 0, height: 0, marginBottom: 0 }}
                    animate={{ opacity: 1, height: "auto", marginBottom: 0 }}
                    exit={{ opacity: 0, height: 0, marginBottom: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden"
                  >
                    <Field
                      id="name"
                      label="Full name"
                      icon={<User className="h-4 w-4" />}
                      value={name}
                      onChange={(v) => setName(v)}
                      onBlur={() => setTouched((t) => ({ ...t, name: true }))}
                      placeholder="Aarav Mehta"
                      error={touched.name ? nameErr : ""}
                      autoComplete="name"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              <Field
                id="email"
                label="Email"
                type="email"
                icon={<Mail className="h-4 w-4" />}
                value={email}
                onChange={(v) => setEmail(v)}
                onBlur={() => setTouched((t) => ({ ...t, email: true }))}
                placeholder="you@grindsync.app"
                error={touched.email ? emailErr : ""}
                autoComplete="email"
              />

              <div>
                <Field
                  id="password"
                  label="Password"
                  icon={<Lock className="h-4 w-4" />}
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={(v) => setPassword(v)}
                  onBlur={() => setTouched((t) => ({ ...t, password: true }))}
                  placeholder={isSignup ? "At least 8 characters" : "••••••••"}
                  error={touched.password ? pwErr : ""}
                  autoComplete={isSignup ? "new-password" : "current-password"}
                  trailing={
                    <button
                      type="button"
                      onClick={() => setShowPw((v) => !v)}
                      aria-label={showPw ? "Hide password" : "Show password"}
                      className="text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {showPw ? (
                        <EyeOff className="h-4 w-4" />
                      ) : (
                        <Eye className="h-4 w-4" />
                      )}
                    </button>
                  }
                />
                {isSignup && password.length > 0 && (
                  <StrengthMeter strength={strength} />
                )}
              </div>

              <AnimatePresence mode="popLayout">
                {isSignup && (
                  <motion.div
                    key="confirm"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden"
                  >
                    <Field
                      id="confirm"
                      label="Confirm password"
                      icon={<Lock className="h-4 w-4" />}
                      type={showPw ? "text" : "password"}
                      value={confirm}
                      onChange={(v) => setConfirm(v)}
                      onBlur={() => setTouched((t) => ({ ...t, confirm: true }))}
                      placeholder="Re-enter password"
                      error={touched.confirm ? confirmErr : ""}
                      autoComplete="new-password"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* remember / forgot (login) or terms (signup) */}
              {isSignup ? (
                <label className="flex items-start gap-2.5 text-xs text-muted-foreground">
                  <input
                    type="checkbox"
                    checked={agree}
                    onChange={(e) => setAgree(e.target.checked)}
                    onBlur={() => setTouched((t) => ({ ...t, agree: true }))}
                    className="mt-0.5 h-4 w-4 shrink-0 rounded border-border accent-brand"
                  />
                  <span>
                    I agree to the{" "}
                    <a href="#" className="font-medium text-brand hover:underline">
                      Terms
                    </a>{" "}
                    and{" "}
                    <a href="#" className="font-medium text-brand hover:underline">
                      Privacy Policy
                    </a>
                    .
                    {termsErr && (
                      <span className="ml-1 text-[oklch(0.65_0.22_25)]">
                        Please accept to continue.
                      </span>
                    )}
                  </span>
                </label>
              ) : (
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 text-xs text-muted-foreground">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) => setRemember(e.target.checked)}
                      className="h-4 w-4 rounded border-border accent-brand"
                    />
                    Remember me
                  </label>
                  <a
                    href="#"
                    className="text-xs font-medium text-brand hover:underline"
                  >
                    Forgot password?
                  </a>
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="mt-1 h-11 gap-2 rounded-xl bg-brand text-base font-semibold text-brand-foreground shadow-[0_8px_30px_-8px_color-mix(in_oklch,var(--color-brand)_60%,transparent)] hover:bg-brand/90 disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {isSignup ? "Creating account…" : "Signing in…"}
                  </>
                ) : (
                  <>
                    {isSignup ? "Create account" : "Sign in"}
                    <ArrowRight className="h-4 w-4" />
                  </>
                )}
              </Button>
            </form>

            {/* switch */}
            <p className="mt-6 text-center text-sm text-muted-foreground">
              {isSignup ? (
                <>
                  Already have an account?{" "}
                  <button
                    onClick={onSwitchMode}
                    className="font-medium text-brand hover:underline"
                  >
                    Sign in
                  </button>
                </>
              ) : null}
            </p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

/* ── Field ─────────────────────────────────────────── */
function Field({
  id,
  label,
  icon,
  value,
  onChange,
  onBlur,
  placeholder,
  type = "text",
  error,
  autoComplete,
  trailing,
}: {
  id: string;
  label: string;
  icon: React.ReactNode;
  value: string;
  onChange: (v: string) => void;
  onBlur?: () => void;
  placeholder?: string;
  type?: string;
  error?: string;
  autoComplete?: string;
  trailing?: React.ReactNode;
}) {
  return (
    <div>
      <label
        htmlFor={id}
        className="mb-1.5 block text-xs font-medium text-foreground"
      >
        {label}
      </label>
      <div
        className={cn(
          "flex items-center gap-2 rounded-lg border bg-muted/30 px-3 transition-colors focus-within:bg-background",
          error
            ? "border-[oklch(0.65_0.22_25)] focus-within:ring-2 focus-within:ring-[oklch(0.65_0.22_25)/0.25]"
            : "border-border focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/20",
        )}
      >
        <span className="text-muted-foreground">{icon}</span>
        <input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onBlur={onBlur}
          placeholder={placeholder}
          autoComplete={autoComplete}
          className="h-11 flex-1 bg-transparent text-sm placeholder:text-muted-foreground/70 focus:outline-none"
        />
        {trailing}
      </div>
      <AnimatePresence>
        {error && (
          <motion.p
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-1 text-[11px] text-[oklch(0.65_0.22_25)]"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── Strength meter ────────────────────────────────── */
function StrengthMeter({ strength }: { strength: { score: number; label: string; bar: string; text: string } }) {
  const segs = 4;
  return (
    <div className="mt-1.5 flex items-center gap-2">
      <div className="flex flex-1 gap-1">
        {Array.from({ length: segs }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "h-1 flex-1 rounded-full transition-colors",
              i < strength.score ? strength.bar : "bg-muted",
            )}
          />
        ))}
      </div>
      <span className={cn("w-12 text-right text-[10px] font-medium", strength.text)}>
        {strength.label}
      </span>
    </div>
  );
}

function scoreStrength(pw: string) {
  let score = 0;
  if (pw.length >= 8) score++;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score++;
  if (/\d/.test(pw)) score++;
  if (/[^A-Za-z0-9]/.test(pw)) score++;
  const map = [
    { label: "—", bar: "bg-muted", text: "text-muted-foreground" },
    { label: "Weak", bar: "bg-[oklch(0.65_0.22_25)]", text: "text-[oklch(0.65_0.22_25)]" },
    { label: "Fair", bar: "bg-[oklch(0.78_0.15_80)]", text: "text-[oklch(0.78_0.15_80)]" },
    { label: "Good", bar: "bg-brand", text: "text-brand" },
    { label: "Strong", bar: "bg-brand", text: "text-brand" },
  ];
  return { score, ...map[score] };
}

/* ── OAuth button ──────────────────────────────────── */
function OAuthButton({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-border bg-background text-sm font-medium transition-colors hover:bg-muted/50"
    >
      {children}
      <span>{label}</span>
    </button>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden>
      <path
        fill="#EA4335"
        d="M12 10.2v3.9h5.5c-.24 1.4-.97 2.6-2.06 3.4l3.1 2.4c1.8-1.7 2.85-4.2 2.85-7.2 0-.7-.06-1.4-.18-2H12z"
      />
      <path
        fill="#4285F4"
        d="M21.94 10.2H12v3.9h5.5c-.24 1.4-.97 2.6-2.06 3.4l3.1 2.4c1.8-1.7 2.85-4.2 2.85-7.2 0-.7-.06-1.4-.18-2H12z"
      />
      <path
        fill="#FBBC05"
        d="M4.7 14.1l-.6.45 2.5 1.95c-.5-1-.8-2.1-.8-3.3 0-1.2.3-2.3.8-3.3L4.1 6.5C3.4 8 3 9.7 3 11.5c0 1.8.4 3.5 1.1 5l.6-1.4z"
      />
      <path
        fill="#34A853"
        d="M12 21c2.7 0 5-.9 6.6-2.4l-3.1-2.4c-.9.6-2 1-3.5 1-2.6 0-4.8-1.7-5.6-4.1l-3.1 2.4C5 19 8.2 21 12 21z"
      />
      <path
        fill="#EA4335"
        d="M12 5.4c1.5 0 2.8.5 3.8 1.5l2.8-2.8C16.8 2.6 14.6 1.8 12 1.8 8.2 1.8 5 3.8 3.5 6.9l3.1 2.4C7.4 7.1 9.5 5.4 12 5.4z"
      />
    </svg>
  );
}
