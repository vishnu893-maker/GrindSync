"use client";

import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { FEATURES } from "./data";

export function FeaturesSection() {
  return (
    <section
      id="features"
      className="scroll-mt-20 border-y border-border bg-muted/20 py-16 sm:py-20 lg:py-24"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <span className="text-xs font-semibold uppercase tracking-wider text-brand">
            Everything connected
          </span>
          <h2 className="mt-3 text-balance text-3xl font-semibold tracking-tight sm:text-4xl">
            Built around proof, not promises.
          </h2>
          <p className="mt-3 text-balance text-sm text-muted-foreground sm:text-base">
            Six pillars that turn scattered effort into one verified developer
            identity.
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <motion.article
              key={f.id}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.4, delay: (i % 3) * 0.08 }}
              className="group relative flex flex-col gap-3 bg-card p-6 transition-colors hover:bg-background"
            >
              <div
                className="h-1 w-10 rounded-full"
                style={{ background: f.accent }}
              />
              <h3 className="text-lg font-semibold tracking-tight">{f.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {f.description}
              </p>
              <ul className="mt-auto flex flex-wrap gap-1.5 pt-2">
                {f.bullets.map((b) => (
                  <li
                    key={b}
                    className="inline-flex items-center gap-1 rounded-md border border-border bg-background/60 px-2 py-0.5 text-[11px] font-medium text-muted-foreground"
                  >
                    <Check className="h-3 w-3 text-brand" />
                    {b}
                  </li>
                ))}
              </ul>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
