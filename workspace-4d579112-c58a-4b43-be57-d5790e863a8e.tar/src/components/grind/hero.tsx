"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { HERO_TICKER } from "./data";
import Antigravity from "./antigravity";
import { RotatingText } from "./rotating-text";
import { ShineButton } from "./shine-button";

function useCountUp(target: number, duration = 1200, start = false) {
  const [value, setValue] = React.useState(0);
  React.useEffect(() => {
    if (!start) return;
    let raf = 0;
    const t0 = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - t0) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(target * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration, start]);
  return value;
}

function parseNumber(label: string) {
  const clean = label.replace(/[^0-9.]/g, "");
  const num = parseFloat(clean);
  const suffix = label.replace(/[0-9.,\s]/g, "");
  return { num, suffix };
}

function AnimatedStat({ value, delay }: { value: string; delay: number }) {
  const { num, suffix } = parseNumber(value);
  const ref = React.useRef<HTMLSpanElement>(null);
  const [started, setStarted] = React.useState(false);
  const v = useCountUp(num, 1400, started);

  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) setStarted(true);
      },
      { threshold: 0.4 },
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const formatted =
    num >= 1000 ? Math.round(v).toLocaleString("en-US") : v.toFixed(1);

  return (
    <motion.span
      ref={ref}
      initial={{ opacity: 0, y: 8 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay }}
      className="tnum"
    >
      {formatted}
      {suffix}
    </motion.span>
  );
}

const ROTATING_WORDS = ["proof", "rank", "clout", "proof"];

export function Hero({
  onSignIn,
  onGetStarted,
}: {
  onSignIn?: () => void;
  onGetStarted?: () => void;
}) {
  return (
    <section
      id="top"
      className="relative isolate overflow-hidden pt-28 pb-16 sm:pt-32 lg:pt-40 lg:pb-24"
    >
      {/* Antigravity particle field (cursor-reactive) */}
      <div className="absolute inset-0 -z-20">
        <Antigravity
          colors={["#10b981", "#34d399", "#6ee7b7"]}
          count={650}
          particleSize={1.05}
          ringRadius={6}
          magnetRadius={9}
          ambient={0.38}
          opacity={0.9}
          particleShape="capsule"
          colorMode="conic"
          colorSpeed={0.04}
          autoAnimate
          className="opacity-80"
        />
      </div>

      {/* Legibility overlay: soft radial vignette so text reads clearly */}
      <div
        aria-hidden
        className="absolute inset-0 -z-10"
        style={{
          background:
            "radial-gradient(ellipse 60% 50% at 50% 42%, color-mix(in oklch, var(--background) 72%, transparent), transparent 70%)",
        }}
      />
      <div className="bg-dot-grid mask-fade-b absolute inset-0 -z-10 opacity-60" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-3xl text-center">
          <motion.a
            href="#changelog"
            initial={{ opacity: 0, y: 6 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="group inline-flex items-center gap-2 rounded-full border border-border bg-background/50 py-1 pl-1 pr-3 text-xs font-medium text-muted-foreground backdrop-blur-md transition-colors hover:text-foreground"
          >
            <span className="inline-flex items-center gap-1 rounded-full bg-brand px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-brand-foreground">
              <Sparkles className="h-3 w-3" /> New
            </span>
            <span>System design tracks are live</span>
            <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
          </motion.a>

          <motion.h1
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="mt-6 flex flex-wrap items-baseline justify-center text-balance text-4xl font-semibold tracking-tight sm:text-5xl lg:text-6xl"
          >
            <span className="mr-3">Turn your grind into</span>
            <span className="relative inline-flex min-w-[3.2em] items-baseline justify-center">
              <RotatingText
                words={ROTATING_WORDS}
                interval={2400}
                gradientClassName="bg-gradient-to-br from-brand via-brand to-brand/60 bg-clip-text text-transparent"
              />
              <svg
                aria-hidden
                viewBox="0 0 200 12"
                className="absolute -bottom-1 left-0 z-0 h-2.5 w-full text-brand/40"
                preserveAspectRatio="none"
              >
                <path
                  d="M2 9 C 50 2, 150 2, 198 8"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              </svg>
            </span>
            <span>.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.12 }}
            className="mx-auto mt-5 max-w-xl text-balance text-base text-muted-foreground sm:text-lg"
          >
            GrindSync auto-tracks your LeetCode, GitHub and coding time — then
            turns it into a verified profile, a live leaderboard rank, and a
            résumé that speaks for itself.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.18 }}
            className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <ShineButton onClick={onGetStarted}>
              Start grinding
              <ArrowRight className="h-4 w-4" />
            </ShineButton>
            <Button
              asChild
              variant="outline"
              size="lg"
              className="h-11 rounded-xl border-border/70 bg-background/40 px-6 text-base backdrop-blur-md hover:bg-background/70"
            >
              <a href="#leaderboard">See the leaderboard</a>
            </Button>
          </motion.div>

          <p className="mt-4 text-xs text-muted-foreground">
            Free during open beta · No credit card · GitHub &amp; Google sign-in
          </p>
        </div>

        {/* Live stat ticker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.26 }}
          className="mx-auto mt-12 grid max-w-4xl grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border/60 backdrop-blur-md lg:grid-cols-4"
        >
          {HERO_TICKER.map((t, i) => (
            <div
              key={t.label}
              className="flex flex-col items-center justify-center gap-1 bg-background/70 px-4 py-5 text-center backdrop-blur-md sm:py-6"
            >
              <div className="text-2xl font-semibold tracking-tight sm:text-3xl">
                <AnimatedStat value={t.value} delay={i * 0.08} />
              </div>
              <div className="text-[11px] uppercase tracking-wide text-muted-foreground sm:text-xs">
                {t.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Trust line */}
        <div className="mt-10 flex flex-col items-center gap-3 text-center">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className="h-3.5 w-3.5 fill-brand text-brand"
                  strokeWidth={0}
                />
              ))}
            </div>
            <span className="text-xs font-medium text-foreground">4.9/5</span>
            <span className="text-xs">from 2,400+ early builders</span>
          </div>
        </div>
      </div>
    </section>
  );
}
