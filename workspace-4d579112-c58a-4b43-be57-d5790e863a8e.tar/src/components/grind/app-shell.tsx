"use client";

import * as React from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bell,
  LayoutGrid,
  LogOut,
  MessageCircle,
  Search,
  Settings,
  Trophy,
  Users,
  Zap,
  Menu,
  X,
  ChevronRight,
  PanelLeftClose,
  PanelLeft,
} from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { ME, NOTIFICATIONS, DM_THREADS } from "./data";
import { cn } from "@/lib/utils";
import { DashboardView } from "./app/dashboard-view";
import { LeaderboardView } from "./app/leaderboard-view";
import { ChallengesView } from "./app/challenges-view";
import { NetworkView } from "./app/network-view";
import { ChatView } from "./app/chat-view";
import { ProfileView } from "./app/profile-view";

type ViewId =
  | "dashboard"
  | "leaderboard"
  | "challenges"
  | "network"
  | "chat"
  | "profile";

const NAV: { id: ViewId; label: string; icon: typeof LayoutGrid; mobile?: boolean }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutGrid, mobile: true },
  { id: "leaderboard", label: "Leaderboard", icon: Trophy, mobile: true },
  { id: "challenges", label: "Challenges", icon: Trophy, mobile: false },
  { id: "network", label: "Network", icon: Users, mobile: true },
  { id: "chat", label: "Chat", icon: MessageCircle, mobile: false },
  { id: "profile", label: "Profile", icon: Settings, mobile: false },
];

const TITLES: Record<ViewId, { title: string; sub: string }> = {
  dashboard: { title: "Dashboard", sub: "Your grind at a glance" },
  leaderboard: { title: "Leaderboard", sub: "Who's shipping right now" },
  challenges: { title: "Challenges", sub: "Sprints that end tutorial hell" },
  network: { title: "Network", sub: "Discover builders worth following" },
  chat: { title: "Messages", sub: "Direct messages with builders" },
  profile: { title: "Profile", sub: "Your living résumé" },
};

const MOBILE_TABS = NAV.filter((n) => n.mobile);

export function AppShell({ onSignOut }: { onSignOut: () => void }) {
  const [view, setView] = React.useState<ViewId>("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = React.useState(false);
  const [notifOpen, setNotifOpen] = React.useState(false);
  const [collapsed, setCollapsed] = React.useState(false);
  const unreadNotifs = NOTIFICATIONS.filter((n) => !n.read).length;
  const unreadChats = DM_THREADS.reduce((s, t) => s + t.unread, 0);

  // persist sidebar collapse preference
  React.useEffect(() => {
    try {
      const saved = localStorage.getItem("gs:sidebar");
      if (saved !== null) setCollapsed(saved === "1");
    } catch {}
  }, []);
  const toggleCollapsed = () => {
    setCollapsed((c) => {
      const next = !c;
      try {
        localStorage.setItem("gs:sidebar", next ? "1" : "0");
      } catch {}
      return next;
    });
  };

  const switchView = (v: ViewId) => {
    setView(v);
    setMobileNavOpen(false);
    if (typeof window !== "undefined") window.scrollTo({ top: 0 });
  };

  return (
    <div className="flex min-h-screen bg-muted/20">
      {/* ── Desktop sidebar ── */}
      <TooltipProvider delayDuration={120}>
        <aside
          className={cn(
            "sticky top-0 hidden h-screen shrink-0 flex-col border-r border-border bg-background transition-[width] duration-200 ease-out md:flex",
            collapsed ? "w-[68px]" : "w-60",
          )}
        >
          <div className={cn("flex h-16 items-center gap-2.5 border-b border-border", collapsed ? "justify-center px-2" : "px-4")}>
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-foreground text-background">
              <Zap className="h-4 w-4" strokeWidth={2.5} />
            </span>
            {!collapsed && (
              <span className="text-[15px] font-semibold tracking-tight">
                Grind<span className="text-brand">Sync</span>
              </span>
            )}
          </div>

          <nav className="flex flex-1 flex-col gap-0.5 p-2">
            {!collapsed && (
              <div className="px-2 pb-1 pt-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                Workspace
              </div>
            )}
            {NAV.map((item) => {
              const Icon = item.icon;
              const active = view === item.id;
              const inner = (
                <button
                  key={item.id}
                  onClick={() => switchView(item.id)}
                  className={cn(
                    "group relative flex items-center rounded-lg text-sm font-medium transition-colors",
                    collapsed ? "h-9 w-9 justify-center" : "w-full gap-2.5 px-2.5 py-2",
                    active
                      ? "bg-muted text-foreground"
                      : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                  )}
                >
                  {active && !collapsed && (
                    <motion.span
                      layoutId="side-active"
                      className="absolute left-0 top-1/2 h-5 w-1 -translate-y-1/2 rounded-r-full bg-brand"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                  <Icon className="h-4 w-4 shrink-0" strokeWidth={active ? 2.4 : 2} />
                  {!collapsed && <span className="flex-1 text-left">{item.label}</span>}
                  {!collapsed && item.id === "chat" && unreadChats > 0 && (
                    <span className="rounded-full bg-brand px-1.5 py-0.5 text-[10px] font-bold text-brand-foreground">
                      {unreadChats}
                    </span>
                  )}
                  {collapsed && item.id === "chat" && unreadChats > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[9px] font-bold text-brand-foreground">
                      {unreadChats}
                    </span>
                  )}
                </button>
              );
              if (collapsed) {
                return (
                  <Tooltip key={item.id}>
                    <TooltipTrigger asChild>{inner}</TooltipTrigger>
                    <TooltipContent side="right" className="text-xs">
                      {item.label}
                      {item.id === "chat" && unreadChats > 0 && (
                        <span className="ml-1 text-brand">({unreadChats})</span>
                      )}
                    </TooltipContent>
                  </Tooltip>
                );
              }
              return inner;
            })}

            <div className="mt-auto">
              {collapsed ? (
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button className="flex h-9 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground">
                      <Settings className="h-4 w-4" />
                    </button>
                  </TooltipTrigger>
                  <TooltipContent side="right" className="text-xs">Settings</TooltipContent>
                </Tooltip>
              ) : (
                <button className="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground">
                  <Settings className="h-4 w-4" />
                  Settings
                </button>
              )}
            </div>
          </nav>

          {/* User card */}
          <div className="border-t border-border p-2">
            <div
              className={cn(
                "flex items-center rounded-lg bg-muted/40",
                collapsed ? "h-9 w-9 justify-center" : "gap-2.5 p-2.5",
              )}
            >
              <Avatar className="h-9 w-9 border border-border">
                <AvatarImage src={ME.avatar} alt={ME.name} />
                <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              {!collapsed && (
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-semibold">{ME.name}</div>
                  <div className="truncate text-[10px] text-muted-foreground">
                    Lvl {ME.level} · {ME.levelName}
                  </div>
                </div>
              )}
              {!collapsed && (
                <button
                  onClick={onSignOut}
                  aria-label="Sign out"
                  className="flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-background hover:text-foreground"
                >
                  <LogOut className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
            {collapsed && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={onSignOut}
                    aria-label="Sign out"
                    className="mt-1 flex h-8 w-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                  </button>
                </TooltipTrigger>
                <TooltipContent side="right" className="text-xs">Sign out</TooltipContent>
              </Tooltip>
            )}
          </div>
        </aside>
      </TooltipProvider>

      {/* ── Main column ── */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="sticky top-0 z-40 flex h-16 items-center gap-3 border-b border-border bg-background/85 px-4 backdrop-blur-xl md:px-6">
          {/* Mobile: menu */}
          <button
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-border text-foreground md:hidden"
            onClick={() => setMobileNavOpen((v) => !v)}
            aria-label="Open menu"
          >
            {mobileNavOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>

          {/* Desktop: sidebar collapse toggle */}
          <button
            onClick={toggleCollapsed}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
            className="hidden h-9 w-9 items-center justify-center rounded-lg border border-border text-muted-foreground transition-colors hover:bg-muted hover:text-foreground md:flex"
          >
            {collapsed ? <PanelLeft className="h-4 w-4" /> : <PanelLeftClose className="h-4 w-4" />}
          </button>

          <div className="min-w-0">
            <h1 className="truncate text-base font-semibold tracking-tight sm:text-lg">
              {TITLES[view].title}
            </h1>
            <p className="hidden truncate text-xs text-muted-foreground sm:block">
              {TITLES[view].sub}
            </p>
          </div>

          <div className="ml-auto flex items-center gap-2">
            {/* Search (desktop) */}
            <div className="relative hidden md:block">
              <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <input
                type="search"
                placeholder="Search builders, repos…"
                className="h-9 w-56 rounded-lg border border-border bg-muted/40 pl-8 pr-3 text-sm placeholder:text-muted-foreground focus:border-brand focus:outline-none focus:ring-1 focus:ring-brand"
              />
            </div>
            <ThemeToggle />

            {/* Notifications */}
            <div className="relative">
              <button
                onClick={() => setNotifOpen((v) => !v)}
                aria-label="Notifications"
                className="relative flex h-9 w-9 items-center justify-center rounded-lg border border-border bg-background text-foreground/80"
              >
                <Bell className="h-4 w-4" />
                {unreadNotifs > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-brand px-1 text-[9px] font-bold text-brand-foreground">
                    {unreadNotifs}
                  </span>
                )}
              </button>
              <AnimatePresence>
                {notifOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setNotifOpen(false)}
                    />
                    <motion.div
                      initial={{ opacity: 0, y: -6, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -6, scale: 0.98 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 top-11 z-50 w-80 overflow-hidden rounded-xl border border-border bg-popover shadow-xl"
                    >
                      <div className="flex items-center justify-between border-b border-border px-3 py-2">
                        <span className="text-xs font-semibold">Notifications</span>
                        <button className="text-[11px] font-medium text-brand hover:underline">
                          Mark all read
                        </button>
                      </div>
                      <ul className="max-h-80 overflow-y-auto scrollbar-thin">
                        {NOTIFICATIONS.map((n) => (
                          <li
                            key={n.id}
                            className={cn(
                              "flex items-start gap-2.5 border-b border-border/60 px-3 py-2.5 last:border-0",
                              !n.read && "bg-brand-soft/30",
                            )}
                          >
                            <span
                              className={cn(
                                "mt-1 h-1.5 w-1.5 shrink-0 rounded-full",
                                n.read ? "bg-transparent" : "bg-brand",
                              )}
                            />
                            <div className="min-w-0 flex-1">
                              <div className="text-xs leading-snug">{n.text}</div>
                              <div className="mt-0.5 text-[10px] text-muted-foreground">
                                {n.time}
                              </div>
                            </div>
                          </li>
                        ))}
                      </ul>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Avatar (mobile, opens nav) */}
            <button
              onClick={() => switchView("profile")}
              className="md:hidden"
              aria-label="Profile"
            >
              <Avatar className="h-9 w-9 border border-border">
                <AvatarImage src={ME.avatar} alt={ME.name} />
                <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
            </button>
          </div>
        </header>

        {/* Mobile drawer nav */}
        <AnimatePresence>
          {mobileNavOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-30 bg-background/80 backdrop-blur-sm md:hidden"
              onClick={() => setMobileNavOpen(false)}
            >
              <motion.nav
                initial={{ x: -16, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -16, opacity: 0 }}
                transition={{ duration: 0.2 }}
                onClick={(e) => e.stopPropagation()}
                className="absolute left-0 top-16 w-64 max-w-[80vw] border-r border-b border-border bg-background p-3 shadow-xl"
              >
                {NAV.map((item) => {
                  const Icon = item.icon;
                  const active = view === item.id;
                  return (
                    <button
                      key={item.id}
                      onClick={() => switchView(item.id)}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2.5 text-sm font-medium",
                        active
                          ? "bg-muted text-foreground"
                          : "text-muted-foreground",
                      )}
                    >
                      <Icon className="h-4 w-4" />
                      <span className="flex-1 text-left">{item.label}</span>
                      {item.id === "chat" && unreadChats > 0 && (
                        <span className="rounded-full bg-brand px-1.5 py-0.5 text-[10px] font-bold text-brand-foreground">
                          {unreadChats}
                        </span>
                      )}
                      <ChevronRight className="h-3.5 w-3.5 opacity-40" />
                    </button>
                  );
                })}
                <button
                  onClick={onSignOut}
                  className="mt-2 flex w-full items-center gap-2.5 rounded-lg border-t border-border px-2.5 py-2.5 text-sm font-medium text-muted-foreground"
                >
                  <LogOut className="h-4 w-4" />
                  Sign out
                </button>
              </motion.nav>
            </motion.div>
          )}
        </AnimatePresence>

        {/* View content */}
        <main className="flex-1 px-4 pb-28 pt-5 md:px-6 md:pb-8 lg:px-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.2 }}
            >
              {view === "dashboard" && <DashboardView onNavigate={switchView} />}
              {view === "leaderboard" && <LeaderboardView />}
              {view === "challenges" && <ChallengesView />}
              {view === "network" && <NetworkView />}
              {view === "chat" && <ChatView />}
              {view === "profile" && <ProfileView />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* ── Mobile bottom nav ── */}
      <MobileBottomNav
        tabs={MOBILE_TABS}
        active={view}
        onChange={switchView}
        unreadChats={unreadChats}
      />
    </div>
  );
}

function MobileBottomNav({
  tabs,
  active,
  onChange,
  unreadChats,
}: {
  tabs: { id: ViewId; label: string; icon: typeof LayoutGrid }[];
  active: ViewId;
  onChange: (v: ViewId) => void;
  unreadChats: number;
}) {
  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background shadow-[0_-8px_24px_-12px_rgba(0,0,0,0.35)] md:hidden"
      aria-label="Primary"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <ul className="mx-auto grid max-w-md grid-cols-4">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = active === tab.id;
          return (
            <li key={tab.id}>
              <button
                onClick={() => onChange(tab.id)}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "relative flex h-14 flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors",
                  isActive ? "text-foreground" : "text-muted-foreground",
                )}
              >
                <span className="relative">
                  <Icon
                    className="h-5 w-5"
                    strokeWidth={isActive ? 2.4 : 2}
                  />
                  {tab.id === "chat" && unreadChats > 0 && (
                    <span className="absolute -right-2 -top-1 flex h-3.5 min-w-3.5 items-center justify-center rounded-full bg-brand px-1 text-[8px] font-bold text-brand-foreground">
                      {unreadChats}
                    </span>
                  )}
                </span>
                <span className="tracking-tight">{tab.label}</span>
                {isActive && (
                  <motion.span
                    layoutId="app-bottom-active"
                    className="absolute -top-px h-0.5 w-8 rounded-full bg-brand"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
