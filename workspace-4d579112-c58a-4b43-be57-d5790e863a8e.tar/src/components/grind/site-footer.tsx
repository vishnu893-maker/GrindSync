"use client";

import Link from "next/link";
import { Zap } from "lucide-react";

const COLUMNS = [
  {
    title: "Product",
    links: ["Dashboard", "Leaderboard", "Challenges", "System design tracks", "Pricing"],
  },
  {
    title: "Builders",
    links: ["Discover", "Top grinders", "Project war room", "Open source", "Community"],
  },
  {
    title: "Resources",
    links: ["Docs", "VS Code extension", "API reference", "Status", "Changelog"],
  },
  {
    title: "Company",
    links: ["About", "Blog", "Careers", "Contact", "Press kit"],
  },
];

export function SiteFooter() {
  return (
    <footer
      id="footer"
      className="mt-auto border-t border-border bg-muted/20"
    >
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-6">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <Link href="#top" className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-foreground text-background">
                <Zap className="h-4 w-4" strokeWidth={2.5} />
              </span>
              <span className="text-[15px] font-semibold tracking-tight">
                Grind<span className="text-brand">Sync</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm text-muted-foreground">
              Proof-of-progress for developers. Turn scattered effort into a
              verified identity you can show.
            </p>
            <div className="mt-4 flex items-center gap-2">
              <SocialLink label="X / Twitter" href="#">
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden>
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </SocialLink>
              <SocialLink label="GitHub" href="#">
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden>
                  <path d="M12 .5C5.37.5 0 5.78 0 12.292c0 5.211 3.438 9.63 8.205 11.188.6.111.82-.254.82-.567 0-.28-.01-1.022-.015-2.005-3.338.711-4.043-1.586-4.043-1.586-.546-1.362-1.333-1.725-1.333-1.725-1.09-.728.082-.713.082-.713 1.205.083 1.84 1.213 1.84 1.213 1.07 1.802 2.808 1.28 3.493.98.108-.76.418-1.28.76-1.574-2.665-.295-5.466-1.302-5.466-5.793 0-1.28.464-2.328 1.236-3.152-.124-.297-.535-1.493.117-3.112 0 0 1.008-.316 3.3 1.202a11.65 11.65 0 013.003-.397c1.018.005 2.044.135 3.003.397 2.29-1.518 3.296-1.202 3.296-1.202.654 1.62.243 2.815.12 3.112.77.824 1.234 1.872 1.234 3.152 0 4.503-2.806 5.494-5.478 5.783.43.362.81 1.076.81 2.168 0 1.566-.014 2.828-.014 3.214 0 .315.216.684.825.567C20.566 21.917 24 17.5 24 12.292 24 5.78 18.627.5 12 .5z" />
                </svg>
              </SocialLink>
              <SocialLink label="Discord" href="#">
                <svg viewBox="0 0 24 24" className="h-4 w-4 fill-current" aria-hidden>
                  <path d="M20.317 4.37a19.79 19.79 0 00-4.885-1.515.074.074 0 00-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 00-5.487 0 12.64 12.64 0 00-.617-1.25.077.077 0 00-.079-.037A19.736 19.736 0 003.677 4.37a.07.07 0 00-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 00.031.057 19.9 19.9 0 005.993 3.03.078.078 0 00.084-.028 14.09 14.09 0 001.226-1.994.076.076 0 00-.041-.106 13.1 13.1 0 01-1.872-.932.077.077 0 01-.008-.128 10.2 10.2 0 00.373-.292.074.074 0 01.077-.01c3.928 1.793 8.18 1.793 12.062 0a074.074 0 01.078.01c.12.098.246.198.373.292a.077.077 0 01-.006.127 12.3 12.3 0 01-1.873.932.077.077 0 00-.041.107c.36.698.772 1.367 1.225 1.993a.076.076 0 00.084.028 19.84 19.84 0 006.002-3.03.077.077 0 00.032-.054c.5-5.177-.838-9.674-3.549-13.66a.06.06 0 00-.031-.027zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z" />
                </svg>
              </SocialLink>
            </div>
          </div>

          {/* Link columns */}
          {COLUMNS.map((col) => (
            <div key={col.title}>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-foreground">
                {col.title}
              </h3>
              <ul className="mt-3 flex flex-col gap-2">
                {col.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-start justify-between gap-4 border-t border-border pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} GrindSync. Built for builders, by
            builders.
          </p>
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <a href="#" className="hover:text-foreground">
              Privacy
            </a>
            <a href="#" className="hover:text-foreground">
              Terms
            </a>
            <a href="#" className="hover:text-foreground">
              Cookies
            </a>
            <span className="inline-flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
              </span>
              All systems operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SocialLink({
  href,
  label,
  children,
}: {
  href: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={href}
      aria-label={label}
      className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-background/40 text-muted-foreground transition-colors hover:text-foreground hover:bg-muted"
    >
      {children}
    </a>
  );
}
