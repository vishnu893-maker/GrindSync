"use client";

import { motion } from "framer-motion";
import { ExternalLink, Flame, Target } from "lucide-react";
import { DAILY_DSA } from "../data";

export function DailyDsa() {
  const diffColor =
    DAILY_DSA.difficulty === "Hard"
      ? "text-[oklch(0.65_0.22_25)] bg-[oklch(0.65_0.22_25/0.12)]"
      : DAILY_DSA.difficulty === "Medium"
        ? "text-[oklch(0.75_0.15_80)] bg-[oklch(0.75_0.15_80/0.12)]"
        : "text-brand bg-brand-soft";

  return (
    <div className="relative flex flex-col gap-4 overflow-hidden rounded-xl border border-border bg-card p-4 sm:p-5">
      <div
        aria-hidden
        className="pointer-events-none absolute -right-12 -top-12 h-40 w-40 rounded-full opacity-50 blur-3xl"
        style={{
          background:
            "radial-gradient(closest-side, color-mix(in oklch, var(--color-brand) 30%, transparent), transparent)",
        }}
      />
      <div className="relative flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <Flame className="h-3.5 w-3.5" />
          Daily DSA
        </div>
        <span
          className={`inline-flex items-center rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${diffColor}`}
        >
          {DAILY_DSA.difficulty}
        </span>
      </div>

      <div className="relative">
        <div className="text-[11px] font-mono text-muted-foreground">
          #{DAILY_DSA.id}
        </div>
        <h4 className="mt-0.5 text-balance text-sm font-semibold leading-snug">
          {DAILY_DSA.title}
        </h4>
        <div className="mt-2 flex flex-wrap gap-1">
          {DAILY_DSA.tags.map((t) => (
            <span
              key={t}
              className="rounded-md border border-border bg-muted/40 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground"
            >
              {t}
            </span>
          ))}
        </div>
      </div>

      <div className="relative flex items-center justify-between gap-3 border-t border-border pt-3">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          <Target className="h-3.5 w-3.5" />
          <span className="tnum">{DAILY_DSA.acRate}%</span>
          <span className="hidden sm:inline">acceptance</span>
        </div>
        <a
          href={DAILY_DSA.url}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 rounded-md bg-brand px-2.5 py-1.5 text-xs font-semibold text-brand-foreground transition-colors hover:bg-brand/90"
        >
          Solve
          <ExternalLink className="h-3 w-3" />
        </a>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.4 }}
        className="relative rounded-lg border border-dashed border-border bg-muted/30 px-2.5 py-1.5 text-[10px] text-muted-foreground"
      >
        ✓ Complete it &amp; earn{" "}
        <span className="font-semibold text-foreground">+150 XP</span> · auto-detected
      </motion.div>
    </div>
  );
}
