"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Calendar,
  GitCommitHorizontal,
  Crown,
  Flame,
  Moon,
  Sword,
  Trophy,
  GitBranch,
  Lock,
  type LucideIcon,
} from "lucide-react";
import { BADGES } from "../data";
import { cn } from "@/lib/utils";

const ICONS: Record<string, LucideIcon> = {
  flame: Flame,
  commit: GitCommitHorizontal,
  sword: Sword,
  git: GitBranch,
  moon: Moon,
  crown: Crown,
  trophy: Trophy,
  calendar: Calendar,
};

const RARITY: Record<
  string,
  { ring: string; glow: string; text: string; chip: string; label: string }
> = {
  common: {
    ring: "from-zinc-400/60 to-zinc-500/30",
    glow: "group-hover:shadow-[0_0_24px_-4px_color-mix(in_oklch,var(--color-muted-foreground)_40%,transparent)]",
    text: "text-zinc-400",
    chip: "bg-zinc-500/10 text-zinc-400",
    label: "Common",
  },
  rare: {
    ring: "from-brand to-brand/50",
    glow: "group-hover:shadow-[0_0_28px_-4px_color-mix(in_oklch,var(--color-brand)_55%,transparent)]",
    text: "text-brand",
    chip: "bg-brand-soft text-brand",
    label: "Rare",
  },
  epic: {
    ring: "from-[oklch(0.78_0.15_80)] to-[oklch(0.78_0.15_80)/40]",
    glow: "group-hover:shadow-[0_0_28px_-4px_color-mix(in_oklch,_0.78_0.15_80_,transparent)]",
    text: "text-[oklch(0.78_0.15_80)]",
    chip: "bg-[oklch(0.78_0.15_80/0.12)] text-[oklch(0.78_0.15_80)]",
    label: "Epic",
  },
  legendary: {
    ring: "from-[oklch(0.7_0.2_300)] to-[oklch(0.7_0.2_300)/40]",
    glow: "group-hover:shadow-[0_0_32px_-2px_color-mix(in_oklch,_0.7_0.2_300_,transparent)]",
    text: "text-[oklch(0.7_0.2_300)]",
    chip: "bg-[oklch(0.7_0.2_300/0.14)] text-[oklch(0.7_0.2_300)]",
    label: "Legendary",
  },
};

export function Badges({ limit }: { limit?: number }) {
  const list = limit ? BADGES.slice(0, limit) : BADGES;
  const earned = list.filter((b) => b.earned).length;

  return (
    <div className="rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between">
        <div className="text-xs font-medium text-muted-foreground">Badges</div>
        <div className="inline-flex items-center gap-1 rounded-full bg-muted/50 px-2 py-0.5 text-[10px] font-semibold">
          <span className="tnum text-brand">{earned}</span>
          <span className="text-muted-foreground">/ {list.length} earned</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
        {list.map((b, i) => {
          const Icon = ICONS[b.icon] ?? Trophy;
          const r = RARITY[b.rarity] ?? RARITY.common;
          return (
            <motion.div
              key={b.id}
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
              whileHover={{ y: -3 }}
              className={cn(
                "group relative flex flex-col items-center gap-2 rounded-lg border p-3 text-center transition-all",
                b.earned
                  ? cn("border-border/70 bg-background/40", r.glow)
                  : "border-dashed border-border/60 bg-muted/20",
              )}
            >
              {/* Medallion */}
              <div className="relative">
                <div
                  className={cn(
                    "absolute -inset-1 rounded-full bg-gradient-to-br opacity-0 blur-md transition-opacity group-hover:opacity-100",
                    r.ring,
                    !b.earned && "opacity-0",
                  )}
                />
                <div
                  className={cn(
                    "relative flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br p-[1.5px]",
                    r.ring,
                    !b.earned && "opacity-40",
                  )}
                >
                  <div className="flex h-full w-full items-center justify-center rounded-full bg-card">
                    <Icon className={cn("h-5 w-5", r.text)} strokeWidth={2.2} />
                  </div>
                </div>
                {!b.earned && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full border border-border bg-card">
                      <Lock className="h-2.5 w-2.5 text-muted-foreground" />
                    </span>
                  </div>
                )}
              </div>

              <div className="space-y-0.5">
                <div className="text-[11px] font-semibold leading-tight">
                  {b.name}
                </div>
                <div className="text-[9px] text-muted-foreground">{b.desc}</div>
              </div>

              <span
                className={cn(
                  "rounded px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide",
                  b.earned ? r.chip : "bg-muted text-muted-foreground",
                )}
              >
                {r.label}
              </span>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
