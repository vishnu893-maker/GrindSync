"use client";

import { motion } from "framer-motion";
import {
  GitCommitHorizontal,
  CheckCircle2,
  Sword,
  UserPlus,
  Crown,
  Plus,
} from "lucide-react";
import { ACTIVITY_FEED } from "../data";

const ICON = {
  commit: { icon: GitCommitHorizontal, color: "var(--chart-1)" },
  dsa: { icon: CheckCircle2, color: "var(--chart-3)" },
  challenge: { icon: Sword, color: "var(--chart-5)" },
  follow: { icon: UserPlus, color: "var(--chart-2)" },
  level: { icon: Crown, color: "var(--chart-4)" },
} as const;

export function ActivityFeed() {
  return (
    <div className="flex flex-col gap-1 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between pb-2">
        <div className="text-xs font-medium text-muted-foreground">
          Recent activity
        </div>
        <button className="text-xs font-medium text-brand hover:underline">
          View all
        </button>
      </div>
      <ul className="flex flex-col">
        {ACTIVITY_FEED.map((a, i) => {
          const meta = ICON[a.type as keyof typeof ICON];
          const Icon = meta.icon;
          return (
            <motion.li
              key={i}
              initial={{ opacity: 0, x: -6 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: i * 0.04 }}
              className="flex items-start gap-3 border-b border-border/50 py-2.5 last:border-0"
            >
              <span
                className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg"
                style={{
                  background: `color-mix(in oklch, ${meta.color} 14%, transparent)`,
                  color: meta.color,
                }}
              >
                <Icon className="h-3.5 w-3.5" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium leading-snug">
                  {a.title}
                </div>
                {a.detail && (
                  <div className="mt-0.5 truncate text-[11px] text-muted-foreground">
                    {a.detail}
                  </div>
                )}
              </div>
              <div className="flex flex-col items-end gap-0.5">
                {a.xp > 0 && (
                  <span className="inline-flex items-center gap-0.5 rounded-md bg-brand-soft px-1.5 py-0.5 text-[9px] font-semibold text-brand">
                    <Plus className="h-2.5 w-2.5" />
                    {a.xp}
                  </span>
                )}
                <span className="text-[10px] text-muted-foreground">
                  {a.time}
                </span>
              </div>
            </motion.li>
          );
        })}
      </ul>
    </div>
  );
}
