"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { Check, Target } from "lucide-react";
import { WEEKLY_GOAL, TODAY_FOCUS } from "../data";
import { ProgressRing } from "./progress-ring";
import { cn } from "@/lib/utils";

export function WeeklyGoal() {
  const [tasks, setTasks] = React.useState(TODAY_FOCUS);
  const pct = Math.round((WEEKLY_GOAL.current / WEEKLY_GOAL.target) * 100);
  const doneCount = tasks.filter((t) => t.done).length;

  const toggle = (id: string) =>
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
    );

  return (
    <div className="flex flex-col gap-4 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
        <Target className="h-3.5 w-3.5" />
        Weekly goal
      </div>

      <div className="flex items-center gap-5">
        <ProgressRing
          value={pct}
          size={104}
          stroke={9}
          label={
            <span className="tnum text-2xl font-semibold">{pct}%</span>
          }
          sublabel={
            <span className="text-[10px] text-muted-foreground">
              of weekly goal
            </span>
          }
        />
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-muted-foreground">XP earned</span>
            <span className="tnum text-sm font-semibold text-brand">
              +{WEEKLY_GOAL.current}
            </span>
          </div>
          <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: `${pct}%` }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, ease: "easeOut" }}
              className="h-full rounded-full bg-brand"
            />
          </div>
          <div className="mt-1 flex items-baseline justify-between text-[10px] text-muted-foreground">
            <span className="tnum">{WEEKLY_GOAL.current}</span>
            <span className="tnum">{WEEKLY_GOAL.target} XP</span>
          </div>
        </div>
      </div>

      {/* Today's focus checklist */}
      <div className="border-t border-border pt-3">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs font-medium text-muted-foreground">
            Today's focus
          </span>
          <span className="tnum text-[10px] text-muted-foreground">
            {doneCount}/{tasks.length} done
          </span>
        </div>
        <ul className="flex flex-col gap-1">
          {tasks.map((t, i) => (
            <motion.li
              key={t.id}
              initial={{ opacity: 0, x: -6 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.25, delay: i * 0.04 }}
            >
              <button
                onClick={() => toggle(t.id)}
                className="flex w-full items-center gap-2 rounded-md px-1.5 py-1.5 text-left transition-colors hover:bg-muted/40"
              >
                <span
                  className={cn(
                    "flex h-4 w-4 shrink-0 items-center justify-center rounded-[5px] border transition-colors",
                    t.done
                      ? "border-brand bg-brand text-brand-foreground"
                      : "border-border bg-background",
                  )}
                >
                  {t.done && <Check className="h-3 w-3" strokeWidth={3} />}
                </span>
                <span
                  className={cn(
                    "flex-1 text-xs leading-tight",
                    t.done
                      ? "text-muted-foreground line-through"
                      : "text-foreground",
                  )}
                >
                  {t.text}
                </span>
                <span
                  className={cn(
                    "tnum text-[10px] font-medium",
                    t.done ? "text-muted-foreground" : "text-brand",
                  )}
                >
                  +{t.xp}
                </span>
              </button>
            </motion.li>
          ))}
        </ul>
      </div>
    </div>
  );
}
