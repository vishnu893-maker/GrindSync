"use client";

import * as React from "react";
import { motion } from "framer-motion";
import { GitCommitHorizontal } from "lucide-react";
import { WEEK_COMMITS, ME } from "../data";

export function CommitChart() {
  const max = Math.max(...WEEK_COMMITS.map((d) => d.commits));
  const total = WEEK_COMMITS.reduce((s, d) => s + d.commits, 0);
  const [hover, setHover] = React.useState<number | null>(null);

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
            <GitCommitHorizontal className="h-3.5 w-3.5" />
            GitHub activity
          </div>
          <div className="mt-0.5 flex items-baseline gap-1.5">
            <span className="tnum text-xl font-semibold">{total}</span>
            <span className="text-xs text-muted-foreground">commits · 7d</span>
          </div>
        </div>
        <span className="inline-flex items-center rounded-md border border-border px-2 py-0.5 text-[10px] font-medium text-muted-foreground">
          {ME.codingTimeWeek}
        </span>
      </div>

      {/* Bars */}
      <div className="relative h-28">
        <div className="absolute inset-0 flex items-end justify-between gap-1.5 sm:gap-2">
          {WEEK_COMMITS.map((d, i) => {
            const h = (d.commits / max) * 100;
            const active = hover === i;
            return (
              <div
                key={d.day}
                className="group relative flex h-full flex-1 flex-col items-center justify-end"
                onMouseEnter={() => setHover(i)}
                onMouseLeave={() => setHover(null)}
              >
                {/* tooltip */}
                {active && (
                  <div className="absolute -top-9 z-10 -translate-x-1/2 left-1/2 whitespace-nowrap rounded-md border border-border bg-popover px-1.5 py-1 text-[10px] font-medium shadow-sm">
                    {d.commits} commits
                  </div>
                )}
                <motion.div
                  initial={{ height: 0 }}
                  whileInView={{ height: `${h}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7, delay: i * 0.05, ease: "easeOut" }}
                  className={`w-full max-w-[26px] rounded-t-md transition-colors ${
                    active ? "bg-brand" : "bg-brand/55"
                  }`}
                  style={{ minHeight: 4 }}
                />
              </div>
            );
          })}
        </div>
        {/* baseline */}
        <div className="absolute inset-x-0 bottom-[18px] h-px bg-border" />
      </div>

      {/* day labels */}
      <div className="flex justify-between gap-1.5 sm:gap-2">
        {WEEK_COMMITS.map((d) => (
          <span
            key={d.day}
            className="flex-1 text-center text-[10px] font-medium text-muted-foreground"
          >
            {d.label}
          </span>
        ))}
      </div>
    </div>
  );
}
