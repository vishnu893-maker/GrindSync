"use client";

import { motion } from "framer-motion";
import { ChevronRight, Flame } from "lucide-react";
import { LEADERBOARD, ME } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

export function MiniLeaderboard() {
  const top = LEADERBOARD.slice(0, 3);
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium text-muted-foreground">
          Top builders
        </div>
        <a
          href="#leaderboard"
          className="inline-flex items-center gap-0.5 text-xs font-medium text-brand hover:underline"
        >
          View all
          <ChevronRight className="h-3 w-3" />
        </a>
      </div>

      <ul className="flex flex-col">
        {top.map((u, i) => (
          <LeaderRow key={u.handle} user={u} delay={i * 0.06} />
        ))}
        {/* Your row */}
        <li className="mt-1 border-t border-dashed border-border pt-1">
          <div className="flex items-center gap-3 rounded-md bg-brand-soft/50 px-2 py-2">
            <div className="tnum w-5 text-center text-xs font-semibold text-brand">
              {ME.rank}
            </div>
            <Avatar className="h-7 w-7 border border-border">
              <AvatarImage src={ME.avatar} alt={ME.name} />
              <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-semibold">
                {ME.name}{" "}
                <span className="font-normal text-brand">(you)</span>
              </div>
              <div className="text-[10px] text-muted-foreground">
                Lvl {ME.level} · {ME.levelName}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Flame className="h-3 w-3 text-[oklch(0.65_0.2_25)]" />
              <span className="tnum text-xs font-semibold">
                {ME.xp.toLocaleString()}
              </span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  );
}

function LeaderRow({
  user,
  delay,
}: {
  user: (typeof LEADERBOARD)[number];
  delay: number;
}) {
  const medal =
    user.rank === 1 ? "🥇" : user.rank === 2 ? "🥈" : user.rank === 3 ? "🥉" : null;
  return (
    <motion.li
      initial={{ opacity: 0, x: -8 }}
      whileInView={{ opacity: 1, x: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.4, delay }}
      className="flex items-center gap-3 rounded-md px-2 py-2 transition-colors hover:bg-muted/60"
    >
      <div className="flex h-5 w-5 items-center justify-center text-sm">
        {medal ?? <span className="tnum text-xs text-muted-foreground">{user.rank}</span>}
      </div>
      <Avatar className="h-7 w-7 border border-border">
        <AvatarImage src={user.avatar} alt={user.name} />
        <AvatarFallback>{user.name.slice(0, 2)}</AvatarFallback>
      </Avatar>
      <div className="min-w-0 flex-1">
        <div className="truncate text-xs font-semibold">{user.name}</div>
        <div className="text-[10px] text-muted-foreground">
          Lvl {user.level} · {user.levelName}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Flame
          className={cn(
            "h-3 w-3",
            user.streak >= 60
              ? "text-[oklch(0.65_0.2_25)]"
              : "text-muted-foreground",
          )}
        />
        <span className="tnum text-xs font-semibold">
          {user.xp.toLocaleString()}
        </span>
      </div>
    </motion.li>
  );
}
