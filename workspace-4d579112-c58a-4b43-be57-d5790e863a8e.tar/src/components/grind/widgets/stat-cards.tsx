"use client";

import { motion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowUpRight,
  Flame,
  GitCommit,
  Target,
  Trophy,
} from "lucide-react";
import { ME, STAT_TRENDS } from "../data";
import { Sparkline } from "./sparkline";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

const CARDS = [
  {
    key: "xp" as const,
    label: "XP this week",
    value: "+975",
    sub: `${ME.xp.toLocaleString()} total`,
    delta: "+12%",
    up: true,
    icon: Trophy,
    accent: "var(--color-brand)",
    spark: STAT_TRENDS.xp,
    tip: "Up 12% vs last week",
  },
  {
    key: "commits" as const,
    label: "Commits today",
    value: "8",
    sub: "54 this week",
    delta: "+3",
    up: true,
    icon: GitCommit,
    accent: "var(--color-chart-2)",
    spark: STAT_TRENDS.commits,
    tip: "3 more than yesterday",
  },
  {
    key: "streak" as const,
    label: "Day streak",
    value: `${ME.streak}`,
    sub: "best: 41d",
    delta: "🔥",
    up: true,
    icon: Flame,
    accent: "var(--color-chart-3)",
    spark: STAT_TRENDS.streak,
    tip: "23 days and counting",
  },
  {
    key: "rank" as const,
    label: "Global rank",
    value: `#${ME.rank}`,
    sub: "of 184k",
    delta: "▲3",
    up: true,
    icon: Target,
    accent: "var(--color-chart-5)",
    spark: STAT_TRENDS.rank,
    tip: "Climbed 3 spots this week",
  },
];

export function StatCards() {
  return (
    <TooltipProvider delayDuration={150}>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {CARDS.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div
              key={c.key}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.35, delay: i * 0.05 }}
              className="group relative flex flex-col gap-2 overflow-hidden rounded-xl border border-border bg-card p-4"
            >
              {/* accent top bar */}
              <div
                className="absolute inset-x-0 top-0 h-0.5 opacity-70"
                style={{ background: c.accent }}
              />
              <div className="flex items-center justify-between">
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-lg"
                  style={{
                    background: `color-mix(in oklch, ${c.accent} 14%, transparent)`,
                    color: c.accent,
                  }}
                >
                  <Icon className="h-4 w-4" />
                </span>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span
                      className={cn(
                        "inline-flex cursor-default items-center gap-0.5 text-[10px] font-semibold",
                        c.up ? "text-brand" : "text-[oklch(0.65_0.22_25)]",
                      )}
                    >
                      {c.delta.startsWith("▲") || c.delta.startsWith("+") ? (
                        c.up ? (
                          <ArrowUpRight className="h-3 w-3" />
                        ) : (
                          <ArrowDownRight className="h-3 w-3" />
                        )
                      ) : null}
                      {c.delta}
                    </span>
                  </TooltipTrigger>
                  <TooltipContent side="bottom" className="text-xs">
                    {c.tip}
                  </TooltipContent>
                </Tooltip>
              </div>
              <div className="flex items-end justify-between gap-2">
                <div>
                  <div className="tnum text-2xl font-semibold tracking-tight">
                    {c.value}
                  </div>
                  <div className="mt-0.5 text-[11px] text-muted-foreground">
                    {c.label}
                  </div>
                  <div className="mt-0.5 text-[10px] text-muted-foreground/70">
                    {c.sub}
                  </div>
                </div>
                <Sparkline
                  data={c.spark}
                  stroke={c.accent}
                  width={64}
                  height={28}
                  className="shrink-0"
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </TooltipProvider>
  );
}
