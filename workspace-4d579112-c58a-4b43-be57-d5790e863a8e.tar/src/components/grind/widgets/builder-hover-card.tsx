"use client";

import * as React from "react";
import { Flame, UserPlus } from "lucide-react";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface BuilderHoverUser {
  name: string;
  handle: string;
  avatar: string;
  level: number;
  levelName: string;
  streak: number;
  tech?: string[];
  followers?: string;
}

export function BuilderHoverCard({
  user,
  children,
  side = "right",
}: {
  user: BuilderHoverUser;
  children: React.ReactNode;
  side?: "top" | "right" | "bottom" | "left";
}) {
  const [following, setFollowing] = React.useState(false);

  return (
    <HoverCard openDelay={200} closeDelay={120}>
      <HoverCardTrigger asChild>
        <span className="inline-flex min-w-0 cursor-pointer items-center">
          {children}
        </span>
      </HoverCardTrigger>
      <HoverCardContent side={side} align="start" className="w-72 p-0">
        <div className="flex flex-col">
          <div className="flex items-start gap-3 p-4">
            <Avatar className="h-11 w-11 border border-border">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.slice(0, 2)}</AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <div className="truncate text-sm font-semibold">{user.name}</div>
              <div className="truncate text-[11px] text-muted-foreground">
                {user.handle}
              </div>
              <div className="mt-1 inline-flex items-center gap-1 rounded-full bg-brand-soft px-1.5 py-0.5 text-[9px] font-semibold text-brand">
                Lvl {user.level} · {user.levelName}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-px border-y border-border bg-border">
            <Stat label="Streak" value={`${user.streak}d`} />
            <Stat label="Followers" value={user.followers ?? "—"} />
            <Stat label="Level" value={`${user.level}`} />
          </div>

          {user.tech && user.tech.length > 0 && (
            <div className="flex flex-wrap gap-1 p-3">
              {user.tech.map((t) => (
                <span
                  key={t}
                  className="rounded border border-border bg-muted/40 px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground"
                >
                  {t}
                </span>
              ))}
            </div>
          )}

          <div className="flex items-center gap-2 p-3 pt-0">
            <Button
              size="sm"
              onClick={() => setFollowing((v) => !v)}
              className={cn(
                "h-8 flex-1 text-xs",
                following
                  ? "border border-border bg-background text-foreground hover:bg-muted"
                  : "bg-brand text-brand-foreground hover:bg-brand/90",
              )}
              variant={following ? "outline" : "default"}
            >
              {following ? "Following" : (
                <>
                  <UserPlus className="h-3.5 w-3.5" /> Follow
                </>
              )}
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="h-8 flex-1 text-xs"
            >
              <Flame className="h-3.5 w-3.5" /> Profile
            </Button>
          </div>
        </div>
      </HoverCardContent>
    </HoverCard>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-card px-2 py-2 text-center">
      <div className="tnum text-sm font-semibold">{value}</div>
      <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
        {label}
      </div>
    </div>
  );
}
