"use client";

import { motion } from "framer-motion";
import { Flame, Zap } from "lucide-react";
import { ME } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

export function ProfileCard() {
  const pct = Math.round((ME.xp / ME.xpToNext) * 100);
  return (
    <div className="relative flex flex-col gap-4 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-11 w-11 border border-border">
            <AvatarImage src={ME.avatar} alt={ME.name} />
            <AvatarFallback>{ME.name.slice(0, 2)}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <div className="truncate text-sm font-semibold">{ME.name}</div>
            <div className="text-xs text-muted-foreground">{ME.handle}</div>
          </div>
        </div>
        <span className="inline-flex items-center gap-1 rounded-full bg-brand-soft px-2 py-1 text-[10px] font-semibold uppercase tracking-wide text-brand">
          <Zap className="h-3 w-3" strokeWidth={2.5} />
          Lvl {ME.level}
        </span>
      </div>

      <div>
        <div className="flex items-baseline justify-between text-xs">
          <span className="text-muted-foreground">{ME.levelName} tier</span>
          <span className="tnum font-medium">
            {ME.xp.toLocaleString()} / {ME.xpToNext.toLocaleString()} XP
          </span>
        </div>
        <div className="mt-1.5 h-2 w-full overflow-hidden rounded-full bg-muted">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${pct}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.9, ease: "easeOut" }}
            className="h-full rounded-full bg-brand"
          />
        </div>
        <div className="mt-1.5 text-[10px] text-muted-foreground">
          {ME.xpToNext - ME.xp} XP to{" "}
          <span className="font-medium text-foreground">level {ME.level + 1}</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 border-t border-border pt-3">
        <Stat label="Streak" value={`${ME.streak}d`} icon={<Flame className="h-3 w-3" />} highlight />
        <Stat label="Commits" value={ME.totalCommits.toLocaleString()} />
        <Stat label="DSA" value={`${ME.dsaSolved}`} />
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  icon,
  highlight,
}: {
  label: string;
  value: string;
  icon?: React.ReactNode;
  highlight?: boolean;
}) {
  return (
    <div className="flex flex-col gap-0.5">
      <div className="flex items-center gap-1 text-[10px] uppercase tracking-wide text-muted-foreground">
        {icon}
        {label}
      </div>
      <div
        className={cn(
          "tnum text-sm font-semibold",
          highlight && "text-brand",
        )}
      >
        {value}
      </div>
    </div>
  );
}
