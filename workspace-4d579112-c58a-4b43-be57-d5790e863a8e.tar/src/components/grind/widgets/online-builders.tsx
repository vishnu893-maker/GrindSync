"use client";

import { motion } from "framer-motion";
import { Circle } from "lucide-react";
import { ONLINE_BUILDERS } from "../data";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

const statusColor: Record<string, string> = {
  shipping: "text-[oklch(0.7_0.15_160)] bg-brand-soft",
  grinding: "text-[oklch(0.75_0.15_80)] bg-[oklch(0.75_0.15_80/0.12)]",
  online: "text-muted-foreground bg-muted",
};

export function OnlineBuilders() {
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-brand opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-brand" />
          </span>
          Builders online
        </div>
        <span className="tnum text-xs font-semibold">1,204</span>
      </div>
      <ul className="flex flex-col">
        {ONLINE_BUILDERS.map((u, i) => (
          <motion.li
            key={u.handle}
            initial={{ opacity: 0, x: -6 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.3, delay: i * 0.05 }}
            className="flex items-center gap-2.5 rounded-md px-1.5 py-1.5 transition-colors hover:bg-muted/50"
          >
            <div className="relative">
              <Avatar className="h-7 w-7 border border-border">
                <AvatarImage src={u.avatar} alt={u.name} />
                <AvatarFallback>{u.name.slice(0, 2)}</AvatarFallback>
              </Avatar>
              <Circle className="absolute -bottom-0.5 -right-0.5 h-2 w-2 fill-brand text-brand" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-medium">{u.name}</div>
              <div className="truncate text-[10px] text-muted-foreground">
                {u.activity}
              </div>
            </div>
            <span
              className={cn(
                "shrink-0 rounded px-1.5 py-0.5 text-[9px] font-semibold capitalize",
                statusColor[u.status],
              )}
            >
              {u.status}
            </span>
          </motion.li>
        ))}
      </ul>
    </div>
  );
}
