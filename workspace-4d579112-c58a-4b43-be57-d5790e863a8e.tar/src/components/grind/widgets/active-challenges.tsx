"use client";

import { motion } from "framer-motion";
import { Clock, Users } from "lucide-react";
import { ACTIVE_CHALLENGES } from "../data";
import { cn } from "@/lib/utils";

const diffStyle: Record<string, string> = {
  Hard: "text-[oklch(0.65_0.22_25)] bg-[oklch(0.65_0.22_25/0.12)]",
  Medium: "text-[oklch(0.75_0.15_80)] bg-[oklch(0.75_0.15_80/0.12)]",
  Easy: "text-brand bg-brand-soft",
};

export function ActiveChallenges() {
  return (
    <div className="flex flex-col gap-2 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <div className="text-xs font-medium text-muted-foreground">
          Active challenges
        </div>
        <a href="#challenges" className="text-xs font-medium text-brand hover:underline">
          Browse
        </a>
      </div>
      <ul className="flex flex-col gap-2">
        {ACTIVE_CHALLENGES.map((c, i) => (
          <motion.li
            key={c.id}
            initial={{ opacity: 0, y: 6 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.35, delay: i * 0.06 }}
            className="group flex flex-col gap-2 rounded-lg border border-border bg-background/40 p-3 transition-colors hover:border-border/80 hover:bg-muted/30"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="rounded-md border border-border bg-muted/40 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
                  {c.tag}
                </span>
                <h5 className="text-xs font-semibold leading-tight">{c.title}</h5>
              </div>
              <span
                className={cn(
                  "shrink-0 rounded px-1.5 py-0.5 text-[9px] font-semibold",
                  diffStyle[c.difficulty],
                )}
              >
                {c.difficulty}
              </span>
            </div>

            {/* progress */}
            <div>
              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <span className="tnum">{c.progress}%</span>
                <span className="tnum">+{c.reward} XP</span>
              </div>
              <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${c.progress}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.8, delay: 0.1 + i * 0.06 }}
                  className="h-full rounded-full bg-brand"
                />
              </div>
            </div>

            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Users className="h-3 w-3" />
                <span className="tnum">{c.participants.toLocaleString()}</span>
              </span>
              <span className="inline-flex items-center gap-1">
                <Clock className="h-3 w-3" />
                <span className="tnum">{c.daysLeft}d left</span>
              </span>
            </div>
          </motion.li>
        ))}
      </ul>
    </div>
  );
}
