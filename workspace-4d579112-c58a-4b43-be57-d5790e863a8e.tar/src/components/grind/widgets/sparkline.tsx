"use client";

import * as React from "react";
import { motion } from "framer-motion";

interface SparklineProps {
  data: number[];
  width?: number;
  height?: number;
  stroke?: string;
  fill?: string;
  className?: string;
  strokeWidth?: number;
}

/**
 * Inline mini line chart (sparkline) for trend micro-viz.
 * Renders an SVG path with an animated draw + soft area fill.
 */
export function Sparkline({
  data,
  width = 72,
  height = 24,
  stroke = "var(--color-brand)",
  fill,
  className,
  strokeWidth = 1.5,
}: SparklineProps) {
  const id = React.useId();
  const safe = data.length ? data : [0, 0];
  const max = Math.max(...safe);
  const min = Math.min(...safe);
  const range = max - min || 1;
  const stepX = width / (safe.length - 1 || 1);

  const points = safe.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 3) - 1.5;
    return [x, y] as const;
  });

  const line = points
    .map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(2)} ${y.toFixed(2)}`)
    .join(" ");
  const area = `${line} L${width} ${height} L0 ${height} Z`;

  const pathRef = React.useRef<SVGPathElement>(null);
  const [len, setLen] = React.useState(0);
  React.useEffect(() => {
    if (pathRef.current) setLen(pathRef.current.getTotalLength());
  }, [line]);

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      className={className}
      preserveAspectRatio="none"
      aria-hidden
    >
      <defs>
        <linearGradient id={`spark-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={fill ?? stroke} stopOpacity="0.22" />
          <stop offset="100%" stopColor={fill ?? stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#spark-${id})`} />
      <motion.path
        ref={pathRef}
        d={line}
        fill="none"
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={len ? { strokeDasharray: len, strokeDashoffset: len } : false}
        animate={len ? { strokeDashoffset: 0 } : {}}
        transition={{ duration: 1, ease: "easeOut" }}
      />
      {/* end dot */}
      <motion.circle
        cx={points[points.length - 1][0]}
        cy={points[points.length - 1][1]}
        r={2}
        fill={stroke}
        initial={{ opacity: 0, scale: 0 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.9 }}
      />
    </svg>
  );
}
