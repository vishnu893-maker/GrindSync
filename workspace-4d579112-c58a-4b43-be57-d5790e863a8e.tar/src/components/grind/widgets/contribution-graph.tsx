"use client";

import * as React from "react";
import { CONTRIBUTION_GRAPH } from "../data";
import { cn } from "@/lib/utils";

const LEVEL_COLOR = [
  "color-mix(in oklch, var(--muted-foreground) 18%, transparent)",
  "color-mix(in oklch, var(--color-brand) 45%, transparent)",
  "color-mix(in oklch, var(--color-brand) 68%, transparent)",
  "color-mix(in oklch, var(--color-brand) 86%, transparent)",
  "var(--color-brand)",
];

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
];

export function ContributionGraph({ compact = false }: { compact?: boolean }) {
  const [hover, setHover] = React.useState<{ w: number; d: number } | null>(null);
  const total = React.useMemo(
    () => CONTRIBUTION_GRAPH.flat().reduce((s, v) => s + (v > 0 ? v * 3 + 1 : 0), 0),
    [],
  );

  // approximate month labels: place a label roughly every ~4-5 weeks
  const monthMarkers = React.useMemo(() => {
    const markers: { label: string; week: number }[] = [];
    let lastMonth = -1;
    CONTRIBUTION_GRAPH.forEach((week, wi) => {
      // pretend week 0 = ~Jan; each week ~0.23 months
      const m = Math.floor((wi / 52) * 12) % 12;
      if (m !== lastMonth && wi % 4 === 0) {
        markers.push({ label: MONTHS[m], week: wi });
        lastMonth = m;
      }
    });
    return markers;
  }, []);

  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <div>
          <div className="text-xs font-medium text-muted-foreground">
            Contribution graph
          </div>
          <div className="mt-0.5 flex items-baseline gap-1.5">
            <span className="tnum text-xl font-semibold">{total}</span>
            <span className="text-xs text-muted-foreground">
              contributions · last year
            </span>
          </div>
        </div>
        {!compact && (
          <div className="hidden items-center gap-1.5 text-[10px] text-muted-foreground sm:flex">
            <span>Less</span>
            {LEVEL_COLOR.map((c, i) => (
              <span
                key={i}
                className="h-2.5 w-2.5 rounded-sm"
                style={{ backgroundColor: c }}
              />
            ))}
            <span>More</span>
          </div>
        )}
      </div>

      <div className="relative -mx-1 overflow-x-auto scrollbar-thin pb-1">
        <div className="flex min-w-max px-1">
          {/* month labels row */}
          <div className="flex h-3 w-[26px] shrink-0" />
          <div className="relative flex-1">
            <div className="flex h-3">
              {Array.from({ length: 52 }).map((_, wi) => {
                const marker = monthMarkers.find((m) => m.week === wi);
                return (
                  <div
                    key={wi}
                    className="flex h-3 w-[12px] items-center justify-start text-[9px] text-muted-foreground"
                    style={{ width: 12, marginRight: 3 }}
                  >
                    {marker ? marker.label : ""}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        <div className="flex min-w-max px-1">
          {/* day labels (Mon/Wed/Fri) */}
          <div className="flex w-[26px] shrink-0 flex-col gap-[3px]">
            {["", "M", "", "W", "", "F", ""].map((d, i) => (
              <div
                key={i}
                className="flex h-[12px] items-center justify-end pr-1 text-[9px] text-muted-foreground"
              >
                {d}
              </div>
            ))}
          </div>

          {/* weeks */}
          <div className="flex flex-1 gap-[3px]">
            {CONTRIBUTION_GRAPH.map((week, wi) => (
              <div key={wi} className="flex flex-col gap-[3px]">
                {week.map((level, di) => (
                  <div
                    key={di}
                    onMouseEnter={() => setHover({ w: wi, d: di })}
                    onMouseLeave={() => setHover(null)}
                    style={{ backgroundColor: LEVEL_COLOR[level] }}
                    className={cn(
                      "h-[12px] w-[12px] rounded-sm transition-transform hover:scale-125 hover:ring-2 hover:ring-foreground/40",
                    )}
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
