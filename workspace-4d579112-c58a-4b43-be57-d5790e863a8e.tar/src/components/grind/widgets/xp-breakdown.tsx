"use client";

import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";
import { XP_BUDGET } from "../data";

export function XpBreakdown() {
  const total = XP_BUDGET.reduce((s, d) => s + d.xp, 0);
  return (
    <div className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <TrendingUp className="h-3.5 w-3.5" />
          XP this week
        </div>
        <span className="tnum text-sm font-semibold">+{total}</span>
      </div>

      {/* Stacked bar */}
      <div className="flex h-2.5 w-full overflow-hidden rounded-full bg-muted">
        {XP_BUDGET.map((d, i) => (
          <motion.div
            key={d.source}
            initial={{ width: 0 }}
            whileInView={{ width: `${(d.xp / total) * 100}%` }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: i * 0.08, ease: "easeOut" }}
            style={{ background: d.color }}
          />
        ))}
      </div>

      {/* Legend */}
      <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
        {XP_BUDGET.map((d) => (
          <div key={d.source} className="flex items-center gap-1.5 text-[11px]">
            <span
              className="h-2 w-2 rounded-sm"
              style={{ background: d.color }}
            />
            <span className="truncate text-muted-foreground">{d.source}</span>
            <span className="tnum ml-auto font-medium">
              {d.xp}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
