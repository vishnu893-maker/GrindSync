import { Experience } from "@/components/grind/experience";

export default function Home() {
  return <Experience />;
}
