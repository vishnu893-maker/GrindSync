import type { Metadata } from "next";
import { Geist, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { CustomCursor } from "@/components/grind/custom-cursor";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "GrindSync — Turn your grind into proof.",
  description:
    "GrindSync is a proof-of-progress network for developers. Auto-track LeetCode, GitHub and coding time. Climb leaderboards, ship in public, and build a verified résumé.",
  keywords: [
    "GrindSync",
    "developer productivity",
    "LeetCode tracker",
    "GitHub activity",
    "developer leaderboard",
    "build in public",
    "DSA challenges",
  ],
  authors: [{ name: "GrindSync" }],
  openGraph: {
    title: "GrindSync — Turn your grind into proof.",
    description:
      "Auto-tracked proof of work for developers. LeetCode, GitHub, coding time — all in one verified profile.",
    siteName: "GrindSync",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "GrindSync — Turn your grind into proof.",
    description:
      "Auto-tracked proof of work for developers. LeetCode, GitHub, coding time — all in one verified profile.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${jetbrainsMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem
          disableTransitionOnChange
        >
          {children}
          <Toaster />
          <CustomCursor />
        </ThemeProvider>
      </body>
    </html>
  );
}
